/**
 * TEST MITRA - SAFE SOUND FEATURE
 * 100% Application-local sound engine using Web Audio API + Speech Synthesis
 * Zero external network dependency, works completely offline.
 */

class SoundService {
  private audioCtx: AudioContext | null = null;
  private soundEnabled: boolean = true;
  private lastClickTime: number = 0;
  private isAppOpenPlayed: boolean = false;
  private listeners: Array<(enabled: boolean) => void> = [];

  constructor() {
    // Load local preference from localStorage (Sound ON by default)
    try {
      const saved = localStorage.getItem('test_mitra_sound_enabled');
      if (saved !== null) {
        this.soundEnabled = saved === 'true';
      }
    } catch {
      this.soundEnabled = true;
    }
  }

  public isEnabled(): boolean {
    return this.soundEnabled;
  }

  public setEnabled(enabled: boolean): void {
    this.soundEnabled = enabled;
    try {
      localStorage.setItem('test_mitra_sound_enabled', enabled ? 'true' : 'false');
    } catch {}
    this.notifyListeners();
  }

  public toggle(): boolean {
    const next = !this.soundEnabled;
    this.setEnabled(next);
    if (next) {
      // Play a quick pleasant test click to confirm sound is back on
      this.playButtonClick();
    }
    return next;
  }

  public subscribe(listener: (enabled: boolean) => void): () => void {
    this.listeners.push(listener);
    listener(this.soundEnabled);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notifyListeners(): void {
    this.listeners.forEach((l) => l(this.soundEnabled));
  }

  private getAudioContext(): AudioContext | null {
    if (!this.audioCtx) {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioContextClass) {
        this.audioCtx = new AudioContextClass();
      }
    }
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume().catch(() => {});
    }
    return this.audioCtx;
  }

  /**
   * App Open:
   * 1. 1-3 seconds soft educational welcome tune (gentle rising chime)
   * 2. Short pleasant voice announcement "ટેસ્ટ મિત્ર" (Test Mitra)
   */
  public playAppOpen(force: boolean = false): void {
    if (!this.soundEnabled) return;
    if (this.isAppOpenPlayed && !force) return;
    this.isAppOpenPlayed = true;

    const ctx = this.getAudioContext();
    if (ctx) {
      if (ctx.state === 'suspended') {
        ctx.resume().catch(() => {});
      }
      const now = ctx.currentTime;
      // Educational warm welcome chord progression (C4, E4, G4, C5)
      const notes = [
        { freq: 261.63, delay: 0.0, dur: 1.2 },  // C4
        { freq: 329.63, delay: 0.15, dur: 1.2 }, // E4
        { freq: 392.00, delay: 0.30, dur: 1.4 }, // G4
        { freq: 523.25, delay: 0.45, dur: 1.6 }, // C5
      ];

      notes.forEach(({ freq, delay, dur }) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + delay);

        gain.gain.setValueAtTime(0, now + delay);
        gain.gain.linearRampToValueAtTime(0.20, now + delay + 0.06);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + delay + dur);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(now + delay);
        osc.stop(now + delay + dur);
      });
    }

    // Voice announcement: "ટેસ્ટ મિત્ર" (Test Mitra)
    const speakVoice = () => {
      try {
        if (!('speechSynthesis' in window) || !this.soundEnabled) return;
        window.speechSynthesis.cancel();
        if (window.speechSynthesis.paused) {
          window.speechSynthesis.resume();
        }

        const voices = window.speechSynthesis.getVoices();
        const guVoice = voices.find((v) => v.lang.startsWith('gu'));
        const inVoice = voices.find(
          (v) => v.lang.startsWith('hi') || v.lang.includes('IN')
        );

        const textToSpeak = guVoice ? 'ટેસ્ટ મિત્ર' : 'Test Mitra';
        const utterance = new SpeechSynthesisUtterance(textToSpeak);
        if (guVoice) {
          utterance.voice = guVoice;
          utterance.lang = 'gu-IN';
        } else if (inVoice) {
          utterance.voice = inVoice;
          utterance.lang = inVoice.lang;
        } else {
          utterance.lang = 'en-US';
        }

        utterance.rate = 0.95;
        utterance.pitch = 1.15;
        utterance.volume = 1.0;

        window.speechSynthesis.speak(utterance);
      } catch {}
    };

    setTimeout(() => {
      speakVoice();
      if ('speechSynthesis' in window && window.speechSynthesis.getVoices().length === 0) {
        window.speechSynthesis.onvoiceschanged = () => {
          speakVoice();
        };
      }
    }, 350);
  }

  public resetAppOpen(): void {
    this.isAppOpenPlayed = false;
  }

  /**
   * Button Click Sound:
   * Short, soft, pleasant click (50ms).
   * Includes duplicate sound prevention (debounce rapid repeated clicks < 60ms).
   */
  public playButtonClick(): void {
    if (!this.soundEnabled) return;
    const now = Date.now();
    if (now - this.lastClickTime < 60) return; // Deduplicate
    this.lastClickTime = now;

    const ctx = this.getAudioContext();
    if (!ctx) return;

    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    // High subtle click with rapid exponential drop
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(950, t);
    osc.frequency.exponentialRampToValueAtTime(450, t + 0.045);

    gain.gain.setValueAtTime(0.12, t);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.045);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(t);
    osc.stop(t + 0.048);
  }

  /**
   * Test Start:
   * Short pleasant start sound (bright two-tone upward chime).
   */
  public playTestStart(): void {
    if (!this.soundEnabled) return;
    const ctx = this.getAudioContext();
    if (!ctx) return;

    const t = ctx.currentTime;
    const tones = [
      { freq: 440, delay: 0.0, dur: 0.25 }, // A4
      { freq: 554.37, delay: 0.12, dur: 0.4 }, // C#5
      { freq: 659.25, delay: 0.24, dur: 0.6 }, // E5
    ];

    tones.forEach(({ freq, delay, dur }) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t + delay);

      gain.gain.setValueAtTime(0, t + delay);
      gain.gain.linearRampToValueAtTime(0.18, t + delay + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + delay + dur);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(t + delay);
      osc.stop(t + delay + dur);
    });
  }

  /**
   * Correct Answer:
   * Short positive pleasant chime.
   */
  public playCorrect(): void {
    if (!this.soundEnabled) return;
    const ctx = this.getAudioContext();
    if (!ctx) return;

    const t = ctx.currentTime;
    const notes = [
      { freq: 523.25, delay: 0.0, dur: 0.2 }, // C5
      { freq: 659.25, delay: 0.08, dur: 0.35 }, // E5
      { freq: 783.99, delay: 0.16, dur: 0.5 }, // G5
    ];

    notes.forEach(({ freq, delay, dur }) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t + delay);

      gain.gain.setValueAtTime(0, t + delay);
      gain.gain.linearRampToValueAtTime(0.2, t + delay + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + delay + dur);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(t + delay);
      osc.stop(t + delay + dur);
    });
  }

  /**
   * Wrong Answer:
   * Short soft error sound (gentle low tone, not harsh).
   */
  public playWrong(): void {
    if (!this.soundEnabled) return;
    const ctx = this.getAudioContext();
    if (!ctx) return;

    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(280, t);
    osc.frequency.exponentialRampToValueAtTime(220, t + 0.18);

    gain.gain.setValueAtTime(0.16, t);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.22);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(t);
    osc.stop(t + 0.24);
  }

  /**
   * Save:
   * Short success sound (bright bell chime).
   */
  public playSave(): void {
    if (!this.soundEnabled) return;
    const ctx = this.getAudioContext();
    if (!ctx) return;

    const t = ctx.currentTime;
    const notes = [
      { freq: 587.33, delay: 0.0, dur: 0.2 }, // D5
      { freq: 880.00, delay: 0.1, dur: 0.4 }, // A5
    ];

    notes.forEach(({ freq, delay, dur }) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, t + delay);

      gain.gain.setValueAtTime(0, t + delay);
      gain.gain.linearRampToValueAtTime(0.18, t + delay + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + delay + dur);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(t + delay);
      osc.stop(t + delay + dur);
    });
  }

  /**
   * Test Completed:
   * Short completion celebratory fanfare (4 ascending harmonious chimes).
   */
  public playTestComplete(): void {
    if (!this.soundEnabled) return;
    const ctx = this.getAudioContext();
    if (!ctx) return;

    const t = ctx.currentTime;
    const chord = [
      { freq: 440.00, delay: 0.0, dur: 0.3 },  // A4
      { freq: 554.37, delay: 0.12, dur: 0.35 }, // C#5
      { freq: 659.25, delay: 0.24, dur: 0.4 },  // E5
      { freq: 880.00, delay: 0.36, dur: 0.7 },  // A5
    ];

    chord.forEach(({ freq, delay, dur }) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t + delay);

      gain.gain.setValueAtTime(0, t + delay);
      gain.gain.linearRampToValueAtTime(0.2, t + delay + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + delay + dur);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(t + delay);
      osc.stop(t + delay + dur);
    });
  }

  /**
   * Error:
   * Short warning sound (soft two-pulse alert).
   */
  public playError(): void {
    if (!this.soundEnabled) return;
    const ctx = this.getAudioContext();
    if (!ctx) return;

    const t = ctx.currentTime;
    const pulses = [
      { freq: 300, delay: 0.0, dur: 0.1 },
      { freq: 260, delay: 0.12, dur: 0.14 },
    ];

    pulses.forEach(({ freq, delay, dur }) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, t + delay);

      gain.gain.setValueAtTime(0, t + delay);
      gain.gain.linearRampToValueAtTime(0.12, t + delay + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + delay + dur);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(t + delay);
      osc.stop(t + delay + dur);
    });
  }

  /**
   * Delete:
   * Short descending click/whoosh sound for item removal.
   */
  public playDelete(): void {
    if (!this.soundEnabled) return;
    const ctx = this.getAudioContext();
    if (!ctx) return;

    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(380, t);
    osc.frequency.exponentialRampToValueAtTime(140, t + 0.12);

    gain.gain.setValueAtTime(0.14, t);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.14);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(t);
    osc.stop(t + 0.15);
  }
}

export const SoundManager = new SoundService();
