import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { User, TestItem, QuestionItem, EnrichedResult, ResultModel } from '../types';

export const DEFAULT_SUPABASE_URL = 'https://vyxcerbdrjjphhqoksup.supabase.co';
export const DEFAULT_SUPABASE_ANON_KEY =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZ5eGNlcmJkcmpqcGhocW9rc3VwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODY4NDk3NjEsImV4cCI6MjEwMjQyNTc2MX0.OHDfLOryTSMSYKd1iBqbblvTFFPg8UED_kb1W0-NOwU';

class SupabaseService {
  private client: SupabaseClient;
  private currentUrl: string;
  private currentKey: string;
  private usersCache: Map<number, string> = new Map();

  constructor() {
    const savedUrl = localStorage.getItem('test_mitra_supabase_url') || DEFAULT_SUPABASE_URL;
    const savedKey = localStorage.getItem('test_mitra_supabase_key') || DEFAULT_SUPABASE_ANON_KEY;
    this.currentUrl = savedUrl.trim();
    this.currentKey = savedKey.trim();
    this.client = createClient(this.currentUrl, this.currentKey);
  }

  public getClient(): SupabaseClient {
    return this.client;
  }

  public getConfig(): { url: string; key: string } {
    return { url: this.currentUrl, key: this.currentKey };
  }

  public setConfig(url: string, key: string): void {
    this.currentUrl = url.trim();
    this.currentKey = key.trim();
    localStorage.setItem('test_mitra_supabase_url', this.currentUrl);
    localStorage.setItem('test_mitra_supabase_key', this.currentKey);
    this.client = createClient(this.currentUrl, this.currentKey);
  }

  public async checkConnection(): Promise<{ success: boolean; message: string }> {
    try {
      const { data, error } = await this.client
        .from('tests')
        .select('id,test_name')
        .limit(1);
      if (error) {
        return { success: false, message: error.message };
      }
      return { success: true, message: `Connected! Tests found: ${data?.length || 0}` };
    } catch (e: unknown) {
      return { success: false, message: e instanceof Error ? e.message : 'Connection failed' };
    }
  }

  public getDeviceId(): string {
    let id = localStorage.getItem('test_mitra_device_id');
    if (!id) {
      id = 'dev_' + Math.random().toString(36).substring(2, 12);
      localStorage.setItem('test_mitra_device_id', id);
    }
    return id;
  }

  // Auth & Login
  public async login(
    mobileNumber: string,
    passwordInput: string,
    forceSwitchDevice: boolean = false
  ): Promise<{ user?: User; error?: string; isDeviceActiveOnAnotherPhone?: boolean }> {
    try {
      const cleanMobile = mobileNumber.trim();
      const cleanPassword = passwordInput.trim();
      const deviceId = this.getDeviceId();

      const { data: users, error } = await this.client
        .from('users')
        .select('*')
        .eq('mobile_number', cleanMobile);

      if (error) {
        return { error: error.message };
      }
      if (!users || users.length === 0) {
        return { error: 'User not found or invalid credentials' };
      }

      const matched = users.find((u: User) => (u.password || '').trim() === cleanPassword);
      if (!matched) {
        return { error: 'Invalid password' };
      }

      if ((matched.device_id || '').trim() === 'DEACTIVATED') {
        return { error: 'This account has been deactivated by Super Admin.' };
      }

      const isTeacherOrAdmin =
        (matched.role || '').toLowerCase() === 'admin' ||
        (matched.role || '').toLowerCase() === 'teacher';

      // Single device restriction for students
      if (!isTeacherOrAdmin) {
        const activeDevice = (matched.device_id || '').trim();
        if (activeDevice && activeDevice !== deviceId && !forceSwitchDevice) {
          return {
            error:
              'This account is currently active on another device. Please log in on that device or activate here.',
            isDeviceActiveOnAnotherPhone: true,
          };
        }

        // Register this device ID
        await this.client
          .from('users')
          .update({ device_id: deviceId })
          .eq('id', matched.id);
      }

      const loggedInUser: User = { ...matched, device_id: deviceId };
      return { user: loggedInUser };
    } catch (e: unknown) {
      return { error: e instanceof Error ? e.message : 'Login failed' };
    }
  }

  public async clearDeviceId(userId: number): Promise<void> {
    try {
      if (userId > 0) {
        await this.client.from('users').update({ device_id: '' }).eq('id', userId);
      }
    } catch {}
  }

  public async verifySession(
    userId: number,
    expectedDeviceId: string
  ): Promise<{ user?: User; error?: string }> {
    try {
      const { data, error } = await this.client
        .from('users')
        .select('*')
        .eq('id', userId)
        .single();

      if (error || !data) return { error: 'Session invalid' };

      const isTeacherOrAdmin =
        (data.role || '').toLowerCase() === 'admin' ||
        (data.role || '').toLowerCase() === 'teacher';

      if ((data.device_id || '').trim() === 'DEACTIVATED') {
        return { error: 'Account deactivated' };
      }

      if (!isTeacherOrAdmin && expectedDeviceId) {
        const dev = (data.device_id || '').trim();
        if (dev && dev !== expectedDeviceId) {
          return { error: 'Logged in on another device' };
        }
      }

      return { user: data };
    } catch (e: unknown) {
      return { error: e instanceof Error ? e.message : 'Session verification failed' };
    }
  }

  // Tests
  public async getTests(): Promise<{ tests: TestItem[]; error?: string }> {
    try {
      const { data, error } = await this.client
        .from('tests')
        .select('*')
        .order('id', { ascending: false });

      if (error) return { tests: [], error: error.message };
      return { tests: (data || []) as TestItem[] };
    } catch (e: unknown) {
      return { tests: [], error: e instanceof Error ? e.message : 'Failed to load tests' };
    }
  }

  public async updateTestStatus(testId: number, isActive: boolean): Promise<{ success: boolean; error?: string }> {
    try {
      const { error } = await this.client
        .from('tests')
        .update({ is_active: isActive })
        .eq('id', testId);
      if (error) return { success: false, error: error.message };
      return { success: true };
    } catch (e: unknown) {
      return { success: false, error: e instanceof Error ? e.message : 'Error updating status' };
    }
  }

  public async createTest(
    testName: string,
    duration: number,
    testDate?: string | null,
    testDay?: string | null
  ): Promise<{ test?: TestItem; error?: string }> {
    try {
      const { data, error } = await this.client
        .from('tests')
        .insert([
          {
            test_name: testName.trim(),
            duration,
            is_active: true,
            test_date: testDate || null,
            test_day: testDay || null,
          },
        ])
        .select()
        .single();

      if (error) return { error: error.message };
      return { test: data as TestItem };
    } catch (e: unknown) {
      return { error: e instanceof Error ? e.message : 'Error creating test' };
    }
  }

  public async updateTest(
    testId: number,
    testName: string,
    duration: number,
    testDate?: string | null,
    testDay?: string | null
  ): Promise<{ test?: TestItem; error?: string }> {
    try {
      const { data, error } = await this.client
        .from('tests')
        .update({
          test_name: testName.trim(),
          duration,
          test_date: testDate || null,
          test_day: testDay || null,
        })
        .eq('id', testId)
        .select()
        .single();

      if (error) return { error: error.message };
      return { test: data as TestItem };
    } catch (e: unknown) {
      return { error: e instanceof Error ? e.message : 'Error updating test' };
    }
  }

  public async deleteTest(testId: number): Promise<{ success: boolean; error?: string }> {
    try {
      // 1. Delete questions and their passages
      const { data: qData } = await this.client
        .from('questions')
        .select('id,image_url')
        .eq('test_id', testId);

      if (qData) {
        for (const q of qData) {
          await this.client.from('passages').delete().eq('question_id', q.id);
        }
      }

      // 2. Delete test
      const { error } = await this.client.from('tests').delete().eq('id', testId);
      if (error) return { success: false, error: error.message };
      return { success: true };
    } catch (e: unknown) {
      return { success: false, error: e instanceof Error ? e.message : 'Error deleting test' };
    }
  }

  // Questions
  public async getQuestionsForTest(testId: number): Promise<{ questions: QuestionItem[]; error?: string }> {
    try {
      const { data: questions, error } = await this.client
        .from('questions')
        .select('*')
        .eq('test_id', testId)
        .order('id', { ascending: true });

      if (error) return { questions: [], error: error.message };

      const qList = (questions || []) as QuestionItem[];
      const qIds = qList.map((q) => q.id).filter(Boolean);

      if (qIds.length > 0) {
        try {
          const { data: passages } = await this.client
            .from('passages')
            .select('*')
            .in('question_id', qIds);

          if (passages && passages.length > 0) {
            const passMap = new Map<number, string>();
            passages.forEach((p) => {
              const text = p.passage || p.passage_text || p.content || '';
              if (p.question_id && text.trim()) {
                passMap.set(p.question_id, text.trim());
              }
            });

            return {
              questions: qList.map((q) => ({
                ...q,
                passage_text: q.id ? passMap.get(q.id) || q.passage_text : q.passage_text,
              })),
            };
          }
        } catch {}
      }

      return { questions: qList };
    } catch (e: unknown) {
      return { questions: [], error: e instanceof Error ? e.message : 'Failed to load questions' };
    }
  }

  public async addQuestion(
    testId: number,
    questionText: string,
    optA: string,
    optB: string,
    optC: string,
    optD: string,
    correctOpt: string,
    imageUrl?: string | null,
    passageText?: string | null
  ): Promise<{ question?: QuestionItem; error?: string }> {
    try {
      const { data, error } = await this.client
        .from('questions')
        .insert([
          {
            test_id: testId,
            question_text: questionText.trim(),
            option_a: optA.trim(),
            option_b: optB.trim(),
            option_c: optC.trim(),
            option_d: optD.trim(),
            correct_option: correctOpt.trim().toUpperCase(),
            image_url: imageUrl || null,
          },
        ])
        .select()
        .single();

      if (error) return { error: error.message };

      const created = data as QuestionItem;
      if (passageText && passageText.trim() && created.id) {
        await this.client
          .from('passages')
          .insert([{ question_id: created.id, passage: passageText.trim() }]);
        created.passage_text = passageText.trim();
      }

      return { question: created };
    } catch (e: unknown) {
      return { error: e instanceof Error ? e.message : 'Error adding question' };
    }
  }

  public async updateQuestion(
    questionId: number,
    questionText: string,
    optA: string,
    optB: string,
    optC: string,
    optD: string,
    correctOpt: string,
    imageUrl?: string | null,
    passageText?: string | null
  ): Promise<{ question?: QuestionItem; error?: string }> {
    try {
      const { data, error } = await this.client
        .from('questions')
        .update({
          question_text: questionText.trim(),
          option_a: optA.trim(),
          option_b: optB.trim(),
          option_c: optC.trim(),
          option_d: optD.trim(),
          correct_option: correctOpt.trim().toUpperCase(),
          image_url: imageUrl !== undefined ? imageUrl : null,
        })
        .eq('id', questionId)
        .select()
        .single();

      if (error) return { error: error.message };

      const updated = data as QuestionItem;

      // Handle passage
      if (passageText && passageText.trim()) {
        const { data: existing } = await this.client
          .from('passages')
          .select('id')
          .eq('question_id', questionId);

        if (existing && existing.length > 0) {
          await this.client
            .from('passages')
            .update({ passage: passageText.trim() })
            .eq('question_id', questionId);
        } else {
          await this.client
            .from('passages')
            .insert([{ question_id: questionId, passage: passageText.trim() }]);
        }
        updated.passage_text = passageText.trim();
      } else {
        await this.client.from('passages').delete().eq('question_id', questionId);
        updated.passage_text = null;
      }

      return { question: updated };
    } catch (e: unknown) {
      return { error: e instanceof Error ? e.message : 'Error updating question' };
    }
  }

  public async deleteQuestion(questionId: number): Promise<{ success: boolean; error?: string }> {
    try {
      await this.client.from('passages').delete().eq('question_id', questionId);
      const { error } = await this.client.from('questions').delete().eq('id', questionId);
      if (error) return { success: false, error: error.message };
      return { success: true };
    } catch (e: unknown) {
      return { success: false, error: e instanceof Error ? e.message : 'Error deleting question' };
    }
  }

  // Results
  public async submitResult(
    userId: number,
    testId: number,
    score: number
  ): Promise<{ result?: ResultModel; error?: string }> {
    try {
      // Check existing
      const { data: existing } = await this.client
        .from('results')
        .select('*')
        .eq('user_id', userId)
        .eq('test_id', testId);

      if (existing && existing.length > 0) {
        const { data, error } = await this.client
          .from('results')
          .update({ score: Math.round(score) })
          .eq('id', existing[0].id)
          .select()
          .single();

        if (error) return { error: error.message };
        return { result: data as unknown as ResultModel };
      } else {
        const { data, error } = await this.client
          .from('results')
          .insert([{ user_id: userId, test_id: testId, score: Math.round(score) }])
          .select()
          .single();

        if (error) return { error: error.message };
        return { result: data as unknown as ResultModel };
      }
    } catch (e: unknown) {
      return { error: e instanceof Error ? e.message : 'Failed to save test result' };
    }
  }

  public async getStudentResults(userId: number, userMobile: string): Promise<EnrichedResult[]> {
    try {
      const { data: results } = await this.client
        .from('results')
        .select('*')
        .eq('user_id', userId)
        .order('id', { ascending: false });

      const { data: tests } = await this.client.from('tests').select('*');
      const testMap = new Map<number, TestItem>();
      (tests || []).forEach((t: TestItem) => {
        if (t.id) testMap.set(t.id, t);
      });

      return (results || []).map((r) => {
        const test = testMap.get(r.test_id);
        return {
          id: r.id,
          userId: r.user_id,
          userMobile,
          testId: r.test_id,
          testName: test?.test_name || `Test #${r.test_id}`,
          testDuration: test?.duration || 15,
          score: r.score,
          createdAt: r.created_at,
        };
      });
    } catch {
      return [];
    }
  }

  public async getResultsForTestAdmin(testId: number, totalMarks?: number | null): Promise<ResultModel[]> {
    try {
      if (this.usersCache.size === 0) {
        const { data: users } = await this.client.from('users').select('id,name,mobile_number');
        (users || []).forEach((u) => {
          if (u.id) this.usersCache.set(u.id, u.name || u.mobile_number || `Student #${u.id}`);
        });
      }

      const { data: results, error } = await this.client
        .from('results')
        .select('*')
        .eq('test_id', testId)
        .order('score', { ascending: false });

      if (error || !results) return [];

      return results.map((r, idx) => ({
        id: String(r.id || idx),
        testId: String(testId),
        studentName: this.usersCache.get(r.user_id) || `Student #${r.user_id}`,
        score: r.score,
        totalMarks: totalMarks || null,
        createdAt: r.created_at,
      }));
    } catch {
      return [];
    }
  }

  // Users Management
  public async getAllUsers(): Promise<{ users: User[]; error?: string }> {
    try {
      const { data, error } = await this.client
        .from('users')
        .select('*')
        .order('id', { ascending: true });

      if (error) return { users: [], error: error.message };
      return { users: (data || []) as User[] };
    } catch (e: unknown) {
      return { users: [], error: e instanceof Error ? e.message : 'Failed to fetch users' };
    }
  }

  public async registerUser(
    name: string,
    mobile: string,
    pass: string,
    role: string = 'student'
  ): Promise<{ user?: User; error?: string }> {
    try {
      const cleanMobile = mobile.trim();
      const cleanName = name.trim();
      const cleanPass = pass.trim();

      const { data: existing } = await this.client
        .from('users')
        .select('id')
        .eq('mobile_number', cleanMobile);

      if (existing && existing.length > 0) {
        return { error: 'This mobile number is already registered' };
      }

      const { data, error } = await this.client
        .from('users')
        .insert([
          {
            name: cleanName,
            mobile_number: cleanMobile,
            password: cleanPass,
            role,
            is_super_admin: false,
          },
        ])
        .select()
        .single();

      if (error) return { error: error.message };
      return { user: data as User };
    } catch (e: unknown) {
      return { error: e instanceof Error ? e.message : 'Error registering user' };
    }
  }

  public async updateUser(
    userId: number,
    name: string,
    pass?: string | null,
    mobile?: string | null
  ): Promise<{ user?: User; error?: string }> {
    try {
      const updateData: Partial<User> = { name: name.trim() };
      if (pass && pass.trim()) updateData.password = pass.trim();
      if (mobile && mobile.trim()) updateData.mobile_number = mobile.trim();

      const { data, error } = await this.client
        .from('users')
        .update(updateData)
        .eq('id', userId)
        .select()
        .single();

      if (error) return { error: error.message };
      return { user: data as User };
    } catch (e: unknown) {
      return { error: e instanceof Error ? e.message : 'Error updating user' };
    }
  }

  public async deleteUser(userId: number): Promise<{ success: boolean; error?: string }> {
    try {
      if (userId === 1) return { success: false, error: 'Cannot delete Super Admin account' };
      const { error } = await this.client.from('users').delete().eq('id', userId);
      if (error) return { success: false, error: error.message };
      return { success: true };
    } catch (e: unknown) {
      return { success: false, error: e instanceof Error ? e.message : 'Error deleting user' };
    }
  }

  public async toggleAdminStatus(
    adminId: number,
    deactivate: boolean
  ): Promise<{ success: boolean; error?: string }> {
    try {
      if (adminId === 1) return { success: false, error: 'Cannot deactivate Super Admin' };
      const newDevId = deactivate ? 'DEACTIVATED' : '';
      const { error } = await this.client
        .from('users')
        .update({ device_id: newDevId })
        .eq('id', adminId);

      if (error) return { success: false, error: error.message };
      return { success: true };
    } catch (e: unknown) {
      return { success: false, error: e instanceof Error ? e.message : 'Error updating status' };
    }
  }

  // Image Upload to Supabase Storage
  public async uploadQuestionImage(file: File): Promise<{ url?: string; error?: string }> {
    try {
      const fileName = `q_${Date.now()}_${Math.random().toString(36).substring(2, 8)}.jpg`;
      const { error } = await this.client.storage
        .from('question-images')
        .upload(fileName, file, { contentType: 'image/jpeg', upsert: true });

      if (error) return { error: error.message };

      const { data } = this.client.storage
        .from('question-images')
        .getPublicUrl(fileName);

      return { url: data.publicUrl };
    } catch (e: unknown) {
      return { error: e instanceof Error ? e.message : 'Image upload failed' };
    }
  }
}

export const SupabaseManager = new SupabaseService();
