import { useState } from 'react';
import { SplashScreen } from './screens/SplashScreen';
import { LoginScreen } from './screens/LoginScreen';
import { StudentHomeScreen } from './screens/StudentHomeScreen';
import { TakeTestScreen } from './screens/TakeTestScreen';
import { TestResultScreen } from './screens/TestResultScreen';
import { AdminHomeScreen } from './screens/AdminHomeScreen';
import { SupabaseManager } from './services/supabaseClient';
import { User, AppDestination } from './types';

export default function App() {
  const [currentDestination, setCurrentDestination] = useState<AppDestination>('SPLASH');
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  // Active Test State
  const [activeTestId, setActiveTestId] = useState<number>(0);
  const [activeTestName, setActiveTestName] = useState<string>('');
  const [activeTestDuration, setActiveTestDuration] = useState<number>(15);

  // Result State
  const [resultTotalQuestions, setResultTotalQuestions] = useState<number>(0);
  const [resultCorrectCount, setResultCorrectCount] = useState<number>(0);
  const [resultScore, setResultScore] = useState<number>(0);
  const [resultAnswersJson, setResultAnswersJson] = useState<string>('{}');

  const handleLogout = async () => {
    if (currentUser?.id) {
      await SupabaseManager.clearDeviceId(currentUser.id);
    }
    localStorage.removeItem('test_mitra_current_user');
    setCurrentUser(null);
    setCurrentDestination('LOGIN');
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-800 antialiased">
      {currentDestination === 'SPLASH' && (
        <SplashScreen
          onNavigateToLogin={() => setCurrentDestination('LOGIN')}
          onNavigateToStudentHome={(user) => {
            setCurrentUser(user);
            setCurrentDestination('STUDENT_HOME');
          }}
          onNavigateToAdminHome={(user) => {
            setCurrentUser(user);
            setCurrentDestination('ADMIN_HOME');
          }}
        />
      )}

      {currentDestination === 'LOGIN' && (
        <LoginScreen
          onLoginSuccess={(user) => {
            setCurrentUser(user);
            const isTeacherOrAdmin =
              (user.role || '').toLowerCase() === 'admin' ||
              (user.role || '').toLowerCase() === 'teacher';
            if (isTeacherOrAdmin) {
              setCurrentDestination('ADMIN_HOME');
            } else {
              setCurrentDestination('STUDENT_HOME');
            }
          }}
        />
      )}

      {currentDestination === 'STUDENT_HOME' && currentUser && (
        <StudentHomeScreen
          user={currentUser}
          onStartTest={(testId, testName, duration) => {
            setActiveTestId(testId);
            setActiveTestName(testName);
            setActiveTestDuration(duration);
            setCurrentDestination('TAKE_TEST');
          }}
          onLogout={handleLogout}
        />
      )}

      {currentDestination === 'ADMIN_HOME' && currentUser && (
        <AdminHomeScreen
          user={currentUser}
          onTakeTest={(testId, testName, duration) => {
            setActiveTestId(testId);
            setActiveTestName(testName);
            setActiveTestDuration(duration);
            setCurrentDestination('TAKE_TEST');
          }}
          onLogout={handleLogout}
        />
      )}

      {currentDestination === 'TAKE_TEST' && currentUser && (
        <TakeTestScreen
          testId={activeTestId}
          testName={activeTestName}
          durationMinutes={activeTestDuration}
          user={currentUser}
          onTestFinished={(testId, testName, total, correct, score, answersJson) => {
            setActiveTestId(testId);
            setActiveTestName(testName);
            setResultTotalQuestions(total);
            setResultCorrectCount(correct);
            setResultScore(score);
            setResultAnswersJson(answersJson);
            setCurrentDestination('TEST_RESULT');
          }}
          onCancelTest={() => {
            const isTeacherOrAdmin =
              (currentUser.role || '').toLowerCase() === 'admin' ||
              (currentUser.role || '').toLowerCase() === 'teacher';
            if (isTeacherOrAdmin) {
              setCurrentDestination('ADMIN_HOME');
            } else {
              setCurrentDestination('STUDENT_HOME');
            }
          }}
        />
      )}

      {currentDestination === 'TEST_RESULT' && (
        <TestResultScreen
          testId={activeTestId}
          testName={activeTestName}
          totalQuestions={resultTotalQuestions}
          correctCount={resultCorrectCount}
          score={resultScore}
          answersMapJson={resultAnswersJson}
          onBackToHome={() => {
            const isTeacherOrAdmin =
              (currentUser?.role || '').toLowerCase() === 'admin' ||
              (currentUser?.role || '').toLowerCase() === 'teacher';
            if (isTeacherOrAdmin) {
              setCurrentDestination('ADMIN_HOME');
            } else {
              setCurrentDestination('STUDENT_HOME');
            }
          }}
          onRetakeTest={() => {
            setCurrentDestination('TAKE_TEST');
          }}
        />
      )}
    </div>
  );
}
