import React, { useState } from 'react';
import { X, Upload } from 'lucide-react';
import { QuestionItem } from '../types';
import { SoundManager } from '../services/soundManager';

interface EditQuestionModalProps {
  question: QuestionItem;
  onClose: () => void;
  onSave: (
    questionId: number,
    questionText: string,
    optA: string,
    optB: string,
    optC: string,
    optD: string,
    correctOpt: string,
    imageUrl?: string | null,
    passageText?: string | null
  ) => Promise<void>;
}

export const EditQuestionModal: React.FC<EditQuestionModalProps> = ({
  question,
  onClose,
  onSave,
}) => {
  const [passage, setPassage] = useState(question.passage_text || '');
  const [questionText, setQuestionText] = useState(question.question_text || '');
  const [imageUrl, setImageUrl] = useState(question.image_url || '');
  const [optA, setOptA] = useState(question.option_a || '');
  const [optB, setOptB] = useState(question.option_b || '');
  const [optC, setOptC] = useState(question.option_c || '');
  const [optD, setOptD] = useState(question.option_d || '');
  const [correctOpt, setCorrectOpt] = useState(question.correct_option || 'A');
  const [isSaving, setIsSaving] = useState(false);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    SoundManager.playButtonClick();
    const reader = new FileReader();
    reader.onload = (event) => {
      if (typeof event.target?.result === 'string') {
        setImageUrl(event.target.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    SoundManager.playButtonClick();
    if (!questionText.trim() || !optA.trim() || !optB.trim() || !optC.trim() || !optD.trim()) {
      SoundManager.playError();
      return;
    }

    setIsSaving(true);
    await onSave(
      question.id || 0,
      questionText.trim(),
      optA.trim(),
      optB.trim(),
      optC.trim(),
      optD.trim(),
      correctOpt,
      imageUrl.trim() || null,
      passage.trim() || null
    );
    setIsSaving(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-7 shadow-2xl border border-slate-200 space-y-4 max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 flex-shrink-0">
          <h3 className="text-lg font-bold text-slate-900">Edit Question</h3>
          <button
            type="button"
            onClick={() => {
              SoundManager.playButtonClick();
              onClose();
            }}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto space-y-4 pr-1">
          {/* Paragraph / Poem (Optional) */}
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              Paragraph / Poem (Optional)
            </label>
            <textarea
              rows={3}
              value={passage}
              onChange={(e) => setPassage(e.target.value)}
              placeholder="Enter reading comprehension paragraph/poem if this question is based on one..."
              className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-[#1E3A8A]"
            />
          </div>

          {/* Question Text */}
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              Question Text
            </label>
            <textarea
              rows={3}
              value={questionText}
              onChange={(e) => setQuestionText(e.target.value)}
              placeholder="Type question here..."
              required
              className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-[#1E3A8A]"
            />
          </div>

          {/* Image Upload Box */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
              Question Image (Optional)
            </label>

            <div className="flex flex-wrap items-center gap-2">
              <label className="flex items-center gap-1.5 px-3 py-2 bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 rounded-xl text-xs font-bold cursor-pointer shadow-2xs transition-colors">
                <Upload className="w-4 h-4 text-[#1E3A8A]" />
                <span>Upload Image (JPG / PNG)</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>

              {imageUrl && (
                <button
                  type="button"
                  onClick={() => setImageUrl('')}
                  className="px-2.5 py-1.5 text-xs text-red-600 font-bold hover:bg-red-50 rounded-lg cursor-pointer"
                >
                  Remove Image
                </button>
              )}
            </div>

            {imageUrl && (
              <div className="mt-2 border border-slate-200 rounded-xl p-2 bg-white flex justify-center">
                <img
                  src={imageUrl}
                  alt="Preview"
                  className="max-h-36 object-contain rounded-lg"
                />
              </div>
            )}
          </div>

          {/* Options A, B, C, D */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700">Option A</label>
              <input
                type="text"
                value={optA}
                onChange={(e) => setOptA(e.target.value)}
                placeholder="Option A"
                required
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm font-medium"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700">Option B</label>
              <input
                type="text"
                value={optB}
                onChange={(e) => setOptB(e.target.value)}
                placeholder="Option B"
                required
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm font-medium"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700">Option C</label>
              <input
                type="text"
                value={optC}
                onChange={(e) => setOptC(e.target.value)}
                placeholder="Option C"
                required
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm font-medium"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700">Option D</label>
              <input
                type="text"
                value={optD}
                onChange={(e) => setOptD(e.target.value)}
                placeholder="Option D"
                required
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm font-medium"
              />
            </div>
          </div>

          {/* Correct Option Selector */}
          <div className="space-y-1.5 pt-1">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
              Select Correct Answer
            </label>
            <div className="grid grid-cols-4 gap-2">
              {['A', 'B', 'C', 'D'].map((opt) => (
                <button
                  key={opt}
                  type="button"
                  onClick={() => {
                    SoundManager.playButtonClick();
                    setCorrectOpt(opt);
                  }}
                  className={`py-2 rounded-xl text-xs sm:text-sm font-bold border-2 transition-all cursor-pointer ${
                    correctOpt === opt
                      ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  Option {opt}
                </button>
              ))}
            </div>
          </div>

          {/* Footer Buttons */}
          <div className="flex items-center gap-3 pt-3">
            <button
              type="button"
              onClick={() => {
                SoundManager.playButtonClick();
                onClose();
              }}
              className="flex-1 py-3 px-4 rounded-xl border border-slate-200 text-slate-700 text-xs font-bold hover:bg-slate-50 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="flex-1 py-3 px-4 rounded-xl bg-[#1E3A8A] hover:bg-blue-800 text-white text-xs font-bold shadow-xs transition-colors cursor-pointer flex items-center justify-center gap-2"
            >
              {isSaving ? (
                <div className="w-4 h-4 rounded-full border-2 border-white/30 border-t-white animate-spin" />
              ) : (
                <span>Save Changes</span>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
