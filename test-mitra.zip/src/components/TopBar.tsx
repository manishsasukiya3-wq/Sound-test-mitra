import React, { useEffect, useState } from 'react';
import { Volume2, VolumeX, RefreshCw, LogOut, GraduationCap } from 'lucide-react';
import { SoundManager } from '../services/soundManager';

interface TopBarProps {
  title?: string;
  subtitle?: string;
  onRefresh?: () => void;
  onLogout?: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  title = 'TEST MITRA',
  subtitle,
  onRefresh,
  onLogout,
}) => {
  const [isSoundOn, setIsSoundOn] = useState(SoundManager.isEnabled());
  const [isRefreshing, setIsRefreshing] = useState(false);

  useEffect(() => {
    const unsub = SoundManager.subscribe((enabled) => {
      setIsSoundOn(enabled);
    });
    return unsub;
  }, []);

  const handleToggleSound = () => {
    const next = SoundManager.toggle();
    setIsSoundOn(next);
  };

  const handleRefreshClick = () => {
    SoundManager.playButtonClick();
    if (onRefresh) {
      setIsRefreshing(true);
      onRefresh();
      setTimeout(() => setIsRefreshing(false), 600);
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-[#1E3A8A] text-white shadow-md select-none">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 h-16 flex items-center justify-between gap-2">
        {/* Brand Logo & Name */}
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center shadow-sm flex-shrink-0 border border-blue-200">
            <GraduationCap className="w-6 h-6 text-[#1E3A8A]" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <h1 className="text-base sm:text-lg font-extrabold tracking-wide text-white truncate">
                {title}
              </h1>
              <span className="hidden sm:inline-block text-[10px] uppercase font-bold tracking-widest bg-blue-700/60 px-1.5 py-0.5 rounded border border-blue-500/40 text-blue-100">
                Online
              </span>
            </div>
            {subtitle && (
              <p className="text-xs text-blue-100/90 truncate font-medium">
                {subtitle}
              </p>
            )}
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2 flex-shrink-0">
          {/* Sound Toggle Button (Sound ON / OFF) */}
          <button
            onClick={handleToggleSound}
            title={isSoundOn ? 'Sound is ON (Click to mute)' : 'Sound is OFF (Click to unmute)'}
            aria-label="Toggle Sound"
            className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-bold transition-all border ${
              isSoundOn
                ? 'bg-emerald-600/90 hover:bg-emerald-600 text-white border-emerald-400 shadow-sm'
                : 'bg-red-500/20 hover:bg-red-500/30 text-red-200 border-red-400/50'
            }`}
          >
            {isSoundOn ? (
              <>
                <Volume2 className="w-4 h-4 animate-pulse text-white" />
                <span className="hidden md:inline">Sound ON</span>
              </>
            ) : (
              <>
                <VolumeX className="w-4 h-4 text-red-300" />
                <span className="hidden md:inline">Sound OFF</span>
              </>
            )}
          </button>

          {/* Refresh */}
          {onRefresh && (
            <button
              onClick={handleRefreshClick}
              title="Refresh Data"
              className="p-2 rounded-xl text-blue-100 hover:text-white hover:bg-blue-800/80 transition-colors"
            >
              <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} />
            </button>
          )}

          {/* Logout */}
          {onLogout && (
            <button
              onClick={() => {
                SoundManager.playButtonClick();
                onLogout();
              }}
              title="Logout"
              className="p-2 rounded-xl text-blue-100 hover:text-white hover:bg-red-600/80 transition-colors"
            >
              <LogOut className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
