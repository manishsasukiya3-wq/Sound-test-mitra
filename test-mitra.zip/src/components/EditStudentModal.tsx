import React, { useState } from 'react';
import { X, Lock, User as UserIcon } from 'lucide-react';
import { User } from '../types';
import { SoundManager } from '../services/soundManager';

interface EditStudentModalProps {
  student: User;
  onClose: () => void;
  onUpdate: (studentId: number, name: string, password?: string | null) => Promise<void>;
}

export const EditStudentModal: React.FC<EditStudentModalProps> = ({ student, onClose, onUpdate }) => {
  const [name, setName] = useState(student.name || '');
  const [password, setPassword] = useState('');
  const [isUpdating, setIsUpdating] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    SoundManager.playButtonClick();
    if (!name.trim()) {
      SoundManager.playError();
      return;
    }

    setIsUpdating(true);
    await onUpdate(
      student.id || 0,
      name.trim(),
      password.trim() ? password.trim() : null
    );
    setIsUpdating(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl max-w-sm w-full p-6 sm:p-7 shadow-2xl border border-slate-200 space-y-5">
        <div className="flex items-start justify-between pb-3 border-b border-slate-100">
          <div>
            <h3 className="text-lg font-bold text-slate-900">Edit Student</h3>
            <p className="text-xs text-slate-500 font-mono mt-0.5">
              Mobile: {student.mobile_number}
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              SoundManager.playButtonClick();
              onClose();
            }}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Name Field */}
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              Name
            </label>
            <div className="relative">
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Student Name"
                required
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 pr-10 text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-[#1E3A8A]"
              />
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-slate-400">
                <UserIcon className="w-4 h-4 text-slate-400" />
              </div>
            </div>
          </div>

          {/* New Password (Optional) */}
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              New Password (optional)
            </label>
            <div className="relative">
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Leave blank to keep current"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 pr-10 text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-[#1E3A8A]"
              />
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-slate-400">
                <Lock className="w-4 h-4 text-slate-400" />
              </div>
            </div>
          </div>

          {/* Buttons: Cancel & Update */}
          <div className="flex items-center gap-3 pt-3">
            <button
              type="button"
              onClick={() => {
                SoundManager.playButtonClick();
                onClose();
              }}
              className="flex-1 py-3 px-4 rounded-xl border border-slate-200 text-slate-700 text-xs font-bold hover:bg-slate-50 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isUpdating}
              className="flex-1 py-3 px-4 rounded-xl bg-[#1E3A8A] hover:bg-blue-800 text-white text-xs font-bold shadow-xs transition-colors cursor-pointer flex items-center justify-center gap-2"
            >
              {isUpdating ? (
                <div className="w-4 h-4 rounded-full border-2 border-white/30 border-t-white animate-spin" />
              ) : (
                <span>Update</span>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
