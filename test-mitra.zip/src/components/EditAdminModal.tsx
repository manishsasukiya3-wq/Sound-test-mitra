import React, { useState } from 'react';
import { X, Lock, Phone, User as UserIcon } from 'lucide-react';
import { User } from '../types';
import { SoundManager } from '../services/soundManager';

interface EditAdminModalProps {
  admin: User;
  onClose: () => void;
  onSave: (adminId: number, name: string, mobile: string, password?: string | null) => Promise<void>;
}

export const EditAdminModal: React.FC<EditAdminModalProps> = ({ admin, onClose, onSave }) => {
  const [name, setName] = useState(admin.name || '');
  const [mobile, setMobile] = useState(admin.mobile_number || '');
  const [password, setPassword] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    SoundManager.playButtonClick();
    if (!name.trim() || !mobile.trim()) {
      SoundManager.playError();
      return;
    }

    setIsSaving(true);
    await onSave(
      admin.id || 0,
      name.trim(),
      mobile.trim(),
      password.trim() ? password.trim() : null
    );
    setIsSaving(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl max-w-sm w-full p-6 sm:p-7 shadow-2xl border border-slate-200 space-y-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <h3 className="text-lg font-bold text-slate-900">Edit Admin Details</h3>
          <button
            type="button"
            onClick={() => {
              SoundManager.playButtonClick();
              onClose();
            }}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Admin Name */}
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              Admin Name
            </label>
            <div className="relative">
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Admin Name"
                required
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 pr-10 text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-[#1E3A8A]"
              />
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-slate-400">
                <UserIcon className="w-4 h-4 text-slate-400" />
              </div>
            </div>
          </div>

          {/* Mobile Number */}
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              Mobile Number (10 digits)
            </label>
            <div className="relative">
              <input
                type="tel"
                maxLength={10}
                value={mobile}
                onChange={(e) => setMobile(e.target.value.replace(/\D/g, ''))}
                placeholder="10-digit mobile number"
                required
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 pr-10 text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-[#1E3A8A]"
              />
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-slate-400">
                <Phone className="w-4 h-4 text-slate-400" />
              </div>
            </div>
          </div>

          {/* Password */}
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              Password
            </label>
            <div className="relative">
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Leave blank to keep current"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 pr-10 text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-[#1E3A8A]"
              />
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-slate-400">
                <Lock className="w-4 h-4 text-slate-400" />
              </div>
            </div>
          </div>

          {/* Buttons: Cancel & Save Changes */}
          <div className="flex items-center gap-3 pt-3">
            <button
              type="button"
              onClick={() => {
                SoundManager.playButtonClick();
                onClose();
              }}
              className="flex-1 py-3 px-4 rounded-xl border border-slate-200 text-slate-700 text-xs font-bold hover:bg-slate-50 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="flex-1 py-3 px-4 rounded-xl bg-[#1E3A8A] hover:bg-blue-800 text-white text-xs font-bold shadow-xs transition-colors cursor-pointer flex items-center justify-center gap-2"
            >
              {isSaving ? (
                <div className="w-4 h-4 rounded-full border-2 border-white/30 border-t-white animate-spin" />
              ) : (
                <span>Save Changes</span>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
