import React, { useEffect, useState, useMemo } from 'react';
import { Search, X, Clock, Calendar, CheckCircle, Play, User as UserIcon, BookOpen } from 'lucide-react';
import { TopBar } from '../components/TopBar';
import { SoundManager } from '../services/soundManager';
import { SupabaseManager } from '../services/supabaseClient';
import { User, TestItem, EnrichedResult } from '../types';

interface StudentHomeScreenProps {
  user: User;
  onStartTest: (testId: number, testName: string, duration: number) => void;
  onLogout: () => void;
}

export const StudentHomeScreen: React.FC<StudentHomeScreenProps> = ({
  user,
  onStartTest,
  onLogout,
}) => {
  const [tests, setTests] = useState<TestItem[]>([]);
  const [completedResults, setCompletedResults] = useState<Map<number, EnrichedResult>>(new Map());
  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const loadData = async () => {
    setIsLoading(true);
    setErrorMessage(null);

    // 1. Load active tests
    const testsRes = await SupabaseManager.getTests();
    if (testsRes.error) {
      setErrorMessage(testsRes.error);
    } else {
      // Active tests only, newest first
      const activeList = testsRes.tests.filter((t) => t.is_active !== false);
      setTests(activeList);
    }

    // 2. Load student completed results
    if (user.id) {
      const results = await SupabaseManager.getStudentResults(user.id, user.mobile_number);
      const resMap = new Map<number, EnrichedResult>();
      results.forEach((r) => {
        if (r.testId) resMap.set(r.testId, r);
      });
      setCompletedResults(resMap);
    }

    setIsLoading(false);
  };

  useEffect(() => {
    loadData();
  }, [user.id]);

  // Filter tests by search query (Name, Date, Day)
  const filteredTests = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return tests;

    return tests.filter((t) => {
      const nameMatch = (t.test_name || '').toLowerCase().includes(q);
      const dateMatch = (t.test_date || '').toLowerCase().includes(q);
      const dayMatch = (t.test_day || '').toLowerCase().includes(q);
      return nameMatch || dateMatch || dayMatch;
    });
  }, [tests, searchQuery]);

  const studentDisplayName = user.name || user.mobile_number;

  const handleStartTestClick = (test: TestItem, seqNum: number) => {
    // Play Test Start Sound (Special action sound!)
    SoundManager.playTestStart();
    const formattedTitle = `Test ${seqNum}: ${test.test_name}`;
    onStartTest(test.id || 0, formattedTitle, test.duration || 15);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <TopBar
        title="TEST MITRA"
        subtitle={`Student: ${studentDisplayName}`}
        onRefresh={loadData}
        onLogout={onLogout}
      />

      <main className="max-w-4xl w-full mx-auto p-4 sm:p-6 space-y-4 flex-1">
        {/* Student Profile Card */}
        <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-xs flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-12 h-12 rounded-xl bg-blue-50 border border-blue-100 flex items-center justify-center text-[#1E3A8A] flex-shrink-0">
              <UserIcon className="w-6 h-6" />
            </div>
            <div className="min-w-0">
              <h2 className="text-base sm:text-lg font-bold text-slate-900 truncate">
                {studentDisplayName}
              </h2>
              <p className="text-xs text-slate-500 font-medium">Student Portal</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs font-bold flex-shrink-0">
            <span>{tests.length} Active Tests</span>
          </div>
        </div>

        {/* Search Bar */}
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
            <Search className="w-4 h-4 text-[#1E3A8A]" />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search tests by name, date or day..."
            className="w-full bg-white border border-slate-200 rounded-xl py-3 pl-10 pr-10 text-sm text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-[#1E3A8A] shadow-xs transition-all"
          />
          {searchQuery && (
            <button
              onClick={() => {
                SoundManager.playButtonClick();
                setSearchQuery('');
              }}
              className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-600"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Loading State */}
        {isLoading && tests.length === 0 && (
          <div className="py-20 text-center flex flex-col items-center justify-center space-y-3">
            <div className="w-9 h-9 rounded-full border-3 border-blue-200 border-t-[#1E3A8A] animate-spin" />
            <p className="text-sm font-semibold text-slate-700">Loading tests from Supabase...</p>
          </div>
        )}

        {/* Error State */}
        {errorMessage && (
          <div className="bg-red-50 border border-red-200 rounded-2xl p-6 text-center space-y-3">
            <p className="text-sm font-bold text-red-600">{errorMessage}</p>
            <button
              onClick={() => {
                SoundManager.playButtonClick();
                loadData();
              }}
              className="px-4 py-2 bg-[#1E3A8A] text-white text-xs font-bold rounded-xl shadow cursor-pointer"
            >
              Retry
            </button>
          </div>
        )}

        {/* Empty State */}
        {!isLoading && !errorMessage && filteredTests.length === 0 && (
          <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-3 shadow-xs">
            <div className="w-14 h-14 rounded-2xl bg-slate-100 flex items-center justify-center mx-auto text-slate-400">
              <BookOpen className="w-7 h-7" />
            </div>
            <h3 className="text-base font-bold text-slate-800">
              {searchQuery ? 'No Tests Match Search' : 'No Active Tests Available'}
            </h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              {searchQuery
                ? `No tests found matching "${searchQuery}". Try a different keyword.`
                : 'New MCQ tests published by admin will appear here.'}
            </p>
          </div>
        )}

        {/* Test Cards List */}
        {!isLoading && filteredTests.length > 0 && (
          <div className="space-y-3.5">
            {filteredTests.map((test, index) => {
              // Sequence number calculation: latest test has highest number
              const testSeqNum = tests.length - tests.indexOf(test);
              const completedResult = test.id ? completedResults.get(test.id) : undefined;
              const isCompleted = !!completedResult;

              return (
                <div
                  key={test.id || index}
                  className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-xs hover:shadow-md transition-shadow space-y-3"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="space-y-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="bg-[#1E3A8A] text-white text-[11px] font-bold px-2.5 py-0.5 rounded-md">
                          Test {testSeqNum}
                        </span>
                        {isCompleted && (
                          <span className="bg-emerald-50 text-emerald-700 border border-emerald-200 text-[11px] font-bold px-2 py-0.5 rounded-md flex items-center gap-1">
                            <CheckCircle className="w-3 h-3 text-emerald-600" />
                            Score: {completedResult.score}
                          </span>
                        )}
                      </div>
                      <h3 className="text-base sm:text-lg font-bold text-slate-900 leading-snug">
                        {test.test_name}
                      </h3>
                    </div>

                    <div className="flex-shrink-0">
                      <span className="text-xs font-bold text-[#1E3A8A] bg-blue-50 px-2.5 py-1 rounded-lg border border-blue-100 flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5" />
                        {test.duration} Min
                      </span>
                    </div>
                  </div>

                  {/* Date & Day Badges */}
                  {(test.test_date || test.test_day) && (
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600 pt-1 border-t border-slate-100">
                      {test.test_date && (
                        <span className="inline-flex items-center gap-1 font-semibold text-blue-900 bg-slate-100 px-2 py-0.5 rounded">
                          <Calendar className="w-3 h-3 text-[#1E3A8A]" />
                          {test.test_date}
                        </span>
                      )}
                      {test.test_day && (
                        <span className="inline-flex items-center font-medium text-slate-700 bg-slate-100 px-2 py-0.5 rounded">
                          {test.test_day}
                        </span>
                      )}
                    </div>
                  )}

                  {/* Completed status banner */}
                  {isCompleted && (
                    <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-2.5 flex items-center gap-2 text-emerald-800 text-xs font-bold">
                      <CheckCircle className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                      <span>Test Completed & Saved to Dashboard</span>
                    </div>
                  )}

                  {/* Start / Retake Action Button */}
                  <button
                    onClick={() => handleStartTestClick(test, testSeqNum)}
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 px-4 rounded-xl shadow-sm transition-all flex items-center justify-center gap-2 active:scale-[0.99] cursor-pointer"
                  >
                    <Play className="w-4 h-4 fill-white" />
                    <span>{isCompleted ? 'Retake Test' : 'Start Test'}</span>
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
};
