import React, { useState, useEffect } from 'react';
import {
  Trophy,
  CheckCircle,
  XCircle,
  Home,
  RotateCcw,
  Sparkles,
  BookOpen,
  ZoomIn,
  X,
} from 'lucide-react';
import { SoundManager } from '../services/soundManager';
import { SupabaseManager } from '../services/supabaseClient';
import { QuestionItem } from '../types';

interface TestResultScreenProps {
  testId: number;
  testName: string;
  totalQuestions: number;
  correctCount: number;
  score: number;
  answersMapJson: string;
  onBackToHome: () => void;
  onRetakeTest: () => void;
}

export const TestResultScreen: React.FC<TestResultScreenProps> = ({
  testId,
  testName,
  totalQuestions,
  correctCount,
  score,
  answersMapJson,
  onBackToHome,
  onRetakeTest,
}) => {
  const [questions, setQuestions] = useState<QuestionItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [zoomedImageUrl, setZoomedImageUrl] = useState<string | null>(null);

  const answersMap: Record<string, string> = React.useMemo(() => {
    try {
      return JSON.parse(answersMapJson) || {};
    } catch {
      return {};
    }
  }, [answersMapJson]);

  useEffect(() => {
    const fetchQuestions = async () => {
      setIsLoading(true);
      const res = await SupabaseManager.getQuestionsForTest(testId);
      if (!res.error) {
        setQuestions(res.questions);
      }
      setIsLoading(false);
    };
    fetchQuestions();
  }, [testId]);

  const wrongCount = totalQuestions - correctCount;
  const percentage = totalQuestions > 0 ? (correctCount / totalQuestions) * 100 : 0;

  const grade =
    percentage >= 80
      ? 'Outstanding!'
      : percentage >= 60
      ? 'Good Job!'
      : percentage >= 40
      ? 'Keep Practicing!'
      : 'Needs Improvement';

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col selection:bg-blue-600 selection:text-white">
      {/* Header Bar */}
      <header className="sticky top-0 z-40 bg-[#1E3A8A] text-white shadow-md">
        <div className="max-w-4xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-amber-300" />
            <h1 className="text-base sm:text-lg font-bold text-white">Test Result & Performance</h1>
          </div>
          <button
            onClick={() => {
              SoundManager.playButtonClick();
              onBackToHome();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-800 hover:bg-blue-700 text-xs font-bold text-white transition-colors cursor-pointer"
          >
            <Home className="w-4 h-4" />
            <span className="hidden sm:inline">Home</span>
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl w-full mx-auto p-4 sm:p-6 space-y-5 flex-1 pb-16">
        {/* Score Summary Card */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-md text-center space-y-5">
          <div className="w-20 h-20 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center mx-auto shadow-sm border-2 border-amber-200">
            <Trophy className="w-10 h-10" />
          </div>

          <div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900">{testName}</h2>
            <div className="flex items-center justify-center gap-1.5 mt-1 text-emerald-600 font-extrabold text-sm sm:text-base">
              <Sparkles className="w-4 h-4" />
              <span>{grade}</span>
            </div>
          </div>

          {/* Big Score Numbers */}
          <div className="grid grid-cols-2 gap-3 max-w-sm mx-auto p-4 rounded-2xl bg-slate-50 border border-slate-200">
            <div className="space-y-0.5">
              <span className="text-2xl sm:text-3xl font-black text-[#1E3A8A] font-mono">
                {score} / {totalQuestions}
              </span>
              <p className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                Final Score
              </p>
            </div>
            <div className="space-y-0.5 border-l border-slate-200">
              <span
                className={`text-2xl sm:text-3xl font-black font-mono ${
                  percentage >= 50 ? 'text-emerald-600' : 'text-red-600'
                }`}
              >
                {percentage.toFixed(1)}%
              </span>
              <p className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                Percentage
              </p>
            </div>
          </div>

          {/* Metric Chips */}
          <div className="grid grid-cols-3 gap-2 sm:gap-3 max-w-md mx-auto pt-1">
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 text-center">
              <span className="block text-lg sm:text-xl font-black text-[#1E3A8A]">
                {totalQuestions}
              </span>
              <span className="text-[11px] font-bold text-blue-700">Total</span>
            </div>
            <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 text-center">
              <span className="block text-lg sm:text-xl font-black text-emerald-700">
                {correctCount}
              </span>
              <span className="text-[11px] font-bold text-emerald-700">Correct</span>
            </div>
            <div className="bg-red-50 border border-red-200 rounded-xl p-3 text-center">
              <span className="block text-lg sm:text-xl font-black text-red-600">
                {wrongCount}
              </span>
              <span className="text-[11px] font-bold text-red-600">Wrong</span>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto pt-2">
            <button
              onClick={() => {
                SoundManager.playButtonClick();
                onBackToHome();
              }}
              className="flex-1 bg-[#1E3A8A] hover:bg-blue-800 text-white font-bold py-3 px-4 rounded-xl shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Home className="w-4 h-4" />
              <span>Back to Home</span>
            </button>
            <button
              onClick={() => {
                SoundManager.playTestStart();
                onRetakeTest();
              }}
              className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 px-4 rounded-xl shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Retake Test</span>
            </button>
          </div>
        </div>

        {/* Section Header */}
        <div className="pt-2">
          <h3 className="text-base sm:text-lg font-bold text-slate-900">
            Detailed Question Review ({questions.length})
          </h3>
          <p className="text-xs text-slate-500">Review your chosen answers vs correct solutions</p>
        </div>

        {/* Loading questions */}
        {isLoading && (
          <div className="py-12 text-center">
            <div className="w-8 h-8 rounded-full border-3 border-blue-200 border-t-[#1E3A8A] animate-spin mx-auto mb-2" />
            <span className="text-xs text-slate-500 font-medium">Loading solutions...</span>
          </div>
        )}

        {/* Question Review Cards */}
        {!isLoading && (
          <div className="space-y-4">
            {questions.map((q, idx) => {
              const qId = q.id || 0;
              const studentAnswer = (answersMap[String(qId)] || '').toUpperCase();
              const correctOpt = (q.correct_option || '').trim().toUpperCase().charAt(0);
              const isCorrect = studentAnswer === correctOpt;
              const isUnanswered = !studentAnswer;

              return (
                <div
                  key={qId || idx}
                  className={`bg-white rounded-2xl p-5 border-2 shadow-xs space-y-3.5 transition-all ${
                    isCorrect
                      ? 'border-emerald-300'
                      : isUnanswered
                      ? 'border-slate-200'
                      : 'border-red-300'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="bg-[#1E3A8A] text-white text-xs font-bold px-3 py-1 rounded-md">
                      Question {idx + 1}
                    </span>
                    <span
                      className={`text-xs font-bold px-2.5 py-1 rounded-lg flex items-center gap-1 ${
                        isCorrect
                          ? 'bg-emerald-100 text-emerald-800'
                          : isUnanswered
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-red-100 text-red-800'
                      }`}
                    >
                      {isCorrect ? (
                        <>
                          <CheckCircle className="w-3.5 h-3.5" />
                          <span>Correct</span>
                        </>
                      ) : isUnanswered ? (
                        <span>Unanswered</span>
                      ) : (
                        <>
                          <XCircle className="w-3.5 h-3.5" />
                          <span>Wrong</span>
                        </>
                      )}
                    </span>
                  </div>

                  {/* Passage */}
                  {q.passage_text && q.passage_text.trim() && (
                    <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 text-xs text-slate-700 leading-relaxed whitespace-pre-line font-medium space-y-1">
                      <div className="flex items-center gap-1.5 font-bold text-[#1E3A8A]">
                        <BookOpen className="w-3.5 h-3.5" />
                        <span>Passage / Poem:</span>
                      </div>
                      <p>{q.passage_text}</p>
                    </div>
                  )}

                  {/* Image */}
                  {q.image_url && (
                    <div className="relative rounded-xl overflow-hidden border border-slate-200 bg-slate-50 max-h-56 flex items-center justify-center">
                      <img
                        src={q.image_url}
                        alt="Question Diagram"
                        className="max-h-56 w-auto object-contain cursor-pointer"
                        onClick={() => setZoomedImageUrl(q.image_url || null)}
                      />
                      <button
                        onClick={() => setZoomedImageUrl(q.image_url || null)}
                        className="absolute bottom-2 right-2 bg-black/60 text-white p-1 rounded text-xs flex items-center gap-1"
                      >
                        <ZoomIn className="w-3 h-3" />
                      </button>
                    </div>
                  )}

                  {/* Question Text */}
                  <h4 className="text-sm sm:text-base font-bold text-slate-900 leading-relaxed whitespace-pre-line">
                    {q.question_text}
                  </h4>

                  {/* Options List */}
                  <div className="space-y-1.5 text-xs sm:text-sm">
                    {[
                      { letter: 'A', text: q.option_a },
                      { letter: 'B', text: q.option_b },
                      { letter: 'C', text: q.option_c },
                      { letter: 'D', text: q.option_d },
                    ].map(({ letter, text }) => {
                      const isThisCorrect = correctOpt === letter;
                      const isThisChosen = studentAnswer === letter;

                      let rowClass = 'bg-slate-50 border-slate-200 text-slate-700';
                      if (isThisCorrect) {
                        rowClass = 'bg-emerald-50 border-emerald-400 text-emerald-900 font-semibold';
                      } else if (isThisChosen && !isThisCorrect) {
                        rowClass = 'bg-red-50 border-red-400 text-red-900 font-medium';
                      }

                      return (
                        <div
                          key={letter}
                          className={`p-2.5 sm:p-3 rounded-xl border flex items-center justify-between gap-2.5 ${rowClass}`}
                        >
                          <div className="flex items-center gap-2 min-w-0">
                            <span
                              className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${
                                isThisCorrect
                                  ? 'bg-emerald-600 text-white'
                                  : isThisChosen
                                  ? 'bg-red-600 text-white'
                                  : 'bg-slate-200 text-slate-700'
                              }`}
                            >
                              {letter}
                            </span>
                            <span className="truncate">{text}</span>
                          </div>

                          <div className="flex items-center gap-1 text-[11px] font-bold flex-shrink-0">
                            {isThisCorrect && (
                              <span className="bg-emerald-600 text-white px-2 py-0.5 rounded text-[10px]">
                                Correct Solution
                              </span>
                            )}
                            {isThisChosen && !isThisCorrect && (
                              <span className="bg-red-600 text-white px-2 py-0.5 rounded text-[10px]">
                                Your Choice
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>

      {/* Image Zoom Modal */}
      {zoomedImageUrl && (
        <div
          onClick={() => setZoomedImageUrl(null)}
          className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 backdrop-blur-xs"
        >
          <div className="relative max-w-2xl w-full bg-white rounded-2xl p-4 overflow-hidden">
            <button
              onClick={() => setZoomedImageUrl(null)}
              className="absolute top-3 right-3 bg-slate-100 text-slate-700 p-2 rounded-full hover:bg-slate-200 transition-colors z-10"
            >
              <X className="w-5 h-5" />
            </button>
            <img
              src={zoomedImageUrl}
              alt="Zoomed Question Diagram"
              className="w-full max-h-[80vh] object-contain mx-auto"
            />
          </div>
        </div>
      )}
    </div>
  );
};
