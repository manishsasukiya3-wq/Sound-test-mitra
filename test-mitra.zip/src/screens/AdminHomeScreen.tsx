import React, { useState, useEffect, useMemo } from 'react';
import {
  FileText,
  BarChart3,
  Users,
  ShieldAlert,
  PlusCircle,
  Search,
  X,
  Play,
  RotateCcw,
  Edit2,
  Trash2,
  CheckCircle,
  Clock,
  Calendar,
  ChevronDown,
  ListOrdered,
  Trophy,
  UserPlus,
  Upload,
  User as UserIcon,
} from 'lucide-react';
import { TopBar } from '../components/TopBar';
import { EditTestModal } from '../components/EditTestModal';
import { EditStudentModal } from '../components/EditStudentModal';
import { EditAdminModal } from '../components/EditAdminModal';
import { EditQuestionModal } from '../components/EditQuestionModal';
import { QuestionsViewerModal } from '../components/QuestionsViewerModal';
import { CalendarDatePickerModal } from '../components/CalendarDatePickerModal';
import { ConfirmDeleteModal } from '../components/ConfirmDeleteModal';
import { SoundManager } from '../services/soundManager';
import { SupabaseManager } from '../services/supabaseClient';
import { User, TestItem, QuestionItem, ResultModel, EnrichedResult } from '../types';

interface AdminHomeScreenProps {
  user: User;
  onTakeTest: (testId: number, testName: string, duration: number) => void;
  onLogout: () => void;
}

const DAYS_OF_WEEK = [
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
  'Saturday',
  'Sunday',
];

type AdminTab = 'tests' | 'results' | 'students' | 'admins' | 'create';

export const AdminHomeScreen: React.FC<AdminHomeScreenProps> = ({
  user,
  onTakeTest,
  onLogout,
}) => {
  const isSuperAdmin =
    (user.role || '').toLowerCase() === 'admin' &&
    (user.is_super_admin === true || user.id === 1);

  const [selectedTab, setSelectedTab] = useState<AdminTab>('tests');
  const [tests, setTests] = useState<TestItem[]>([]);
  const [usersList, setUsersList] = useState<User[]>([]);
  const [userCompletedResults, setUserCompletedResults] = useState<Map<number, EnrichedResult>>(new Map());
  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Search States
  const [testSearch, setTestSearch] = useState('');
  const [studentSearch, setStudentSearch] = useState('');
  const [adminSearch, setAdminSearch] = useState('');

  // Results Dashboard State
  const [selectedDashboardTestId, setSelectedDashboardTestId] = useState<number | null>(null);
  const [dashboardResults, setDashboardResults] = useState<ResultModel[]>([]);
  const [isLoadingResults, setIsLoadingResults] = useState(false);
  const [resultStudentFilter, setResultStudentFilter] = useState('');

  // Questions Viewer Modal
  const [viewingQuestionsTest, setViewingQuestionsTest] = useState<TestItem | null>(null);
  const [testQuestions, setTestQuestions] = useState<QuestionItem[]>([]);
  const [isLoadingQuestions, setIsLoadingQuestions] = useState(false);

  // Modals for Editing
  const [testToEdit, setTestToEdit] = useState<TestItem | null>(null);
  const [testToDelete, setTestToDelete] = useState<TestItem | null>(null);
  const [studentToDelete, setStudentToDelete] = useState<User | null>(null);
  const [adminToDelete, setAdminToDelete] = useState<User | null>(null);
  const [editingQuestion, setEditingQuestion] = useState<QuestionItem | null>(null);
  const [editingStudent, setEditingStudent] = useState<User | null>(null);
  const [editingAdmin, setEditingAdmin] = useState<User | null>(null);
  const [showAddStudentModal, setShowAddStudentModal] = useState(false);
  const [showAddAdminModal, setShowAddAdminModal] = useState(false);

  // Create Content Section
  const [createSubTab, setCreateSubTab] = useState<0 | 1>(0); // 0: New Test, 1: Add Question
  const [newTestName, setNewTestName] = useState('');
  const [newTestDuration, setNewTestDuration] = useState('15');
  const [newTestDate, setNewTestDate] = useState('');
  const [newTestDay, setNewTestDay] = useState('');
  const [showNewTestDayDropdown, setShowNewTestDayDropdown] = useState(false);
  const [showCalendarDatePicker, setShowCalendarDatePicker] = useState(false);
  const [isCreatingTest, setIsCreatingTest] = useState(false);

  // Add Question State
  const [selectedAddQuestionTestId, setSelectedAddQuestionTestId] = useState<number | null>(null);
  const [newPassage, setNewPassage] = useState('');
  const [newQuestionText, setNewQuestionText] = useState('');
  const [newOptA, setNewOptA] = useState('');
  const [newOptB, setNewOptB] = useState('');
  const [newOptC, setNewOptC] = useState('');
  const [newOptD, setNewOptD] = useState('');
  const [newCorrectOpt, setNewCorrectOpt] = useState('A');
  const [newImageUrl, setNewImageUrl] = useState('');
  const [isSavingQuestion, setIsSavingQuestion] = useState(false);
  const [createSuccessMsg, setCreateSuccessMsg] = useState<string | null>(null);

  // Snackbar Toast
  const [snackbarMessage, setSnackbarMessage] = useState<string | null>(null);

  const showSnackbar = (msg: string) => {
    setSnackbarMessage(msg);
    setTimeout(() => {
      setSnackbarMessage((prev) => (prev === msg ? null : prev));
    }, 3500);
  };

  const loadAllData = async () => {
    setIsLoading(true);
    setErrorMessage(null);

    const [testsRes, usersRes] = await Promise.all([
      SupabaseManager.getTests(),
      SupabaseManager.getAllUsers(),
    ]);

    if (testsRes.error) {
      setErrorMessage(testsRes.error);
    } else {
      setTests(testsRes.tests);
      if (testsRes.tests.length > 0 && selectedDashboardTestId === null) {
        setSelectedDashboardTestId(testsRes.tests[0].id || null);
      }
      if (testsRes.tests.length > 0 && selectedAddQuestionTestId === null) {
        setSelectedAddQuestionTestId(testsRes.tests[0].id || null);
      }
    }

    if (usersRes.users) {
      setUsersList(usersRes.users);
    }

    // Load user's completed test results
    if (user.id) {
      const results = await SupabaseManager.getStudentResults(user.id, user.mobile_number);
      const resMap = new Map<number, EnrichedResult>();
      results.forEach((r) => {
        if (r.testId) resMap.set(r.testId, r);
      });
      setUserCompletedResults(resMap);
    }

    setIsLoading(false);
  };

  useEffect(() => {
    loadAllData();
  }, []);

  // Fetch results when dashboard test changes
  useEffect(() => {
    if (!selectedDashboardTestId) return;
    const fetchResults = async () => {
      setIsLoadingResults(true);
      const res = await SupabaseManager.getResultsForTestAdmin(selectedDashboardTestId);
      setDashboardResults(res);
      setIsLoadingResults(false);
    };
    fetchResults();
  }, [selectedDashboardTestId]);

  // Filtered Tests
  const filteredTests = useMemo(() => {
    const q = testSearch.trim().toLowerCase();
    if (!q) return tests;
    return tests.filter((t) => {
      const nMatch = (t.test_name || '').toLowerCase().includes(q);
      const dMatch = (t.test_date || '').toLowerCase().includes(q);
      const dayMatch = (t.test_day || '').toLowerCase().includes(q);
      return nMatch || dMatch || dayMatch;
    });
  }, [tests, testSearch]);

  // Filtered Students
  const students = useMemo(() => {
    const list = usersList.filter(
      (u) =>
        (u.role || '').toLowerCase() !== 'admin' &&
        (u.role || '').toLowerCase() !== 'teacher'
    );
    const q = studentSearch.trim().toLowerCase();
    if (!q) return list;
    return list.filter(
      (u) =>
        (u.name || '').toLowerCase().includes(q) ||
        (u.mobile_number || '').includes(q)
    );
  }, [usersList, studentSearch]);

  // Filtered Admins
  const admins = useMemo(() => {
    const list = usersList.filter(
      (u) =>
        (u.role || '').toLowerCase() === 'admin' ||
        (u.role || '').toLowerCase() === 'teacher'
    );
    const q = adminSearch.trim().toLowerCase();
    if (!q) return list;
    return list.filter(
      (u) =>
        (u.name || '').toLowerCase().includes(q) ||
        (u.mobile_number || '').includes(q)
    );
  }, [usersList, adminSearch]);

  // Toggle active status
  const handleToggleActive = async (testId: number, currentStatus: boolean) => {
    SoundManager.playButtonClick();
    const newStatus = !currentStatus;
    setTests((prev) =>
      prev.map((t) => (t.id === testId ? { ...t, is_active: newStatus } : t))
    );
    await SupabaseManager.updateTestStatus(testId, newStatus);
    showSnackbar(`Test is now ${newStatus ? 'Active' : 'Deactivated'}`);
  };

  // View questions
  const handleViewQuestions = async (test: TestItem) => {
    SoundManager.playButtonClick();
    setViewingQuestionsTest(test);
    setIsLoadingQuestions(true);
    setTestQuestions([]);
    if (test.id) {
      const res = await SupabaseManager.getQuestionsForTest(test.id);
      setTestQuestions(res.questions);
    }
    setIsLoadingQuestions(false);
  };

  // Handle Save New Test
  const handleSaveNewTest = async (e: React.FormEvent) => {
    e.preventDefault();
    SoundManager.playButtonClick();
    const name = newTestName.trim();
    const dur = parseInt(newTestDuration) || 15;
    if (!name) {
      SoundManager.playError();
      return;
    }

    setIsCreatingTest(true);
    const res = await SupabaseManager.createTest(
      name,
      dur,
      newTestDate.trim() || null,
      newTestDay.trim() || null
    );
    setIsCreatingTest(false);

    if (res.test) {
      SoundManager.playSave();
      showSnackbar('Test created successfully!');
      setNewTestName('');
      setNewTestDuration('15');
      setNewTestDate('');
      setNewTestDay('');
      await loadAllData();
      if (res.test.id) {
        setSelectedAddQuestionTestId(res.test.id);
      }
      setCreateSubTab(1); // Jump to add questions
    } else {
      SoundManager.playError();
      alert(res.error || 'Failed to create test');
    }
  };

  // Image Upload handler for Add Question
  const handleAddQuestionImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    SoundManager.playButtonClick();
    const reader = new FileReader();
    reader.onload = (event) => {
      if (typeof event.target?.result === 'string') {
        setNewImageUrl(event.target.result);
      }
    };
    reader.readAsDataURL(file);
  };

  // Handle Save Question
  const handleSaveQuestion = async (e: React.FormEvent) => {
    e.preventDefault();
    SoundManager.playButtonClick();
    if (!selectedAddQuestionTestId) {
      SoundManager.playError();
      return;
    }
    if (!newQuestionText.trim() || !newOptA.trim() || !newOptB.trim() || !newOptC.trim() || !newOptD.trim()) {
      SoundManager.playError();
      return;
    }

    setIsSavingQuestion(true);
    const res = await SupabaseManager.addQuestion(
      selectedAddQuestionTestId,
      newQuestionText.trim(),
      newOptA.trim(),
      newOptB.trim(),
      newOptC.trim(),
      newOptD.trim(),
      newCorrectOpt,
      newImageUrl.trim() || null,
      newPassage.trim() || null
    );
    setIsSavingQuestion(false);

    if (res.question) {
      SoundManager.playSave();
      setNewQuestionText('');
      setNewOptA('');
      setNewOptB('');
      setNewOptC('');
      setNewOptD('');
      setNewCorrectOpt('A');
      setNewImageUrl('');
      setNewPassage('');
      setCreateSuccessMsg('Question saved to Supabase successfully!');
      showSnackbar('Question saved to Supabase successfully!');
      setTimeout(() => setCreateSuccessMsg(null), 3500);
    } else {
      SoundManager.playError();
      alert(res.error || 'Failed to save question');
    }
  };

  const handleTabChange = (tab: AdminTab) => {
    SoundManager.playButtonClick();
    setSelectedTab(tab);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col selection:bg-blue-600 selection:text-white">
      <TopBar
        title="TEST MITRA"
        subtitle={isSuperAdmin ? `Super Admin • ${user.name || user.mobile_number}` : `Admin • ${user.name || user.mobile_number}`}
        onRefresh={loadAllData}
        onLogout={onLogout}
      />

      {/* Navigation Tabs Bar */}
      <div className="bg-white border-b border-slate-200 sticky top-16 z-30 shadow-2xs overflow-x-auto scrollbar-none">
        <div className="max-w-5xl mx-auto px-4 flex items-center gap-1 sm:gap-2 h-13">
          <button
            onClick={() => handleTabChange('tests')}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all whitespace-nowrap cursor-pointer ${
              selectedTab === 'tests'
                ? 'bg-blue-50 text-[#1E3A8A] border border-blue-200'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Tests ({tests.length})</span>
          </button>

          <button
            onClick={() => handleTabChange('results')}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all whitespace-nowrap cursor-pointer ${
              selectedTab === 'results'
                ? 'bg-blue-50 text-[#1E3A8A] border border-blue-200'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            <span>Results Dashboard</span>
          </button>

          {/* Students Tab - Super Admin Only */}
          {isSuperAdmin && (
            <button
              onClick={() => handleTabChange('students')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all whitespace-nowrap cursor-pointer ${
                selectedTab === 'students'
                  ? 'bg-blue-50 text-[#1E3A8A] border border-blue-200'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>Students ({students.length})</span>
            </button>
          )}

          {/* Admins Tab - Super Admin Only */}
          {isSuperAdmin && (
            <button
              onClick={() => handleTabChange('admins')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all whitespace-nowrap cursor-pointer ${
                selectedTab === 'admins'
                  ? 'bg-blue-50 text-[#1E3A8A] border border-blue-200'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <ShieldAlert className="w-4 h-4" />
              <span>Admins ({admins.length})</span>
            </button>
          )}

          <button
            onClick={() => handleTabChange('create')}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all whitespace-nowrap cursor-pointer ${
              selectedTab === 'create'
                ? 'bg-emerald-50 text-emerald-800 border border-emerald-300'
                : 'text-emerald-700 hover:bg-emerald-50/50'
            }`}
          >
            <PlusCircle className="w-4 h-4 text-emerald-600" />
            <span>+ Create / Add</span>
          </button>
        </div>
      </div>

      {/* Main Tab Content */}
      <main className="max-w-5xl w-full mx-auto p-4 sm:p-6 flex-1 pb-16">
        {/* ==========================================================
            TAB 0: TESTS MANAGEMENT (Matches Screenshot 1)
           ========================================================== */}
        {selectedTab === 'tests' && (
          <div className="space-y-4">
            {/* Search Bar */}
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <Search className="w-4 h-4 text-[#1E3A8A]" />
              </div>
              <input
                type="text"
                value={testSearch}
                onChange={(e) => setTestSearch(e.target.value)}
                placeholder="Search tests by name, date or day..."
                className="w-full bg-white border border-slate-200 rounded-xl py-3 pl-10 pr-10 text-sm text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-[#1E3A8A] shadow-xs"
              />
              {testSearch && (
                <button
                  onClick={() => {
                    SoundManager.playButtonClick();
                    setTestSearch('');
                  }}
                  className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Test Cards List */}
            {filteredTests.length === 0 ? (
              <div className="bg-white rounded-2xl p-12 text-center border border-slate-200 shadow-xs space-y-2">
                <p className="text-base font-bold text-slate-800">
                  {testSearch ? 'No tests match your search' : 'No tests created yet'}
                </p>
                <p className="text-xs text-slate-500">
                  Go to &apos;+ Create / Add&apos; tab to create your first test.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredTests.map((test) => {
                  const seqNum = tests.length - tests.indexOf(test);
                  const isActive = test.is_active !== false;
                  const completedResult = test.id ? userCompletedResults.get(test.id) : undefined;
                  const isCompleted = !!completedResult;

                  return (
                    <div
                      key={test.id}
                      className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-xs space-y-3.5 hover:shadow-sm transition-shadow"
                    >
                      {/* Top Header Row with Badges */}
                      <div className="flex items-start justify-between gap-3">
                        <div className="space-y-1.5 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="bg-[#1E3A8A] text-white text-xs font-bold px-2.5 py-0.5 rounded-md">
                              Test {seqNum}
                            </span>

                            {isCompleted && (
                              <span className="bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-bold px-2.5 py-0.5 rounded-md flex items-center gap-1">
                                <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                                Score: {completedResult.score}
                              </span>
                            )}

                            <span
                              className={`text-[11px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1 ${
                                isActive
                                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                  : 'bg-slate-100 text-slate-600 border border-slate-200'
                              }`}
                            >
                              <span
                                className={`w-2 h-2 rounded-full ${
                                  isActive ? 'bg-emerald-500' : 'bg-slate-400'
                                }`}
                              />
                              {isActive ? 'Active' : 'Deactive'}
                            </span>
                          </div>

                          <h3 className="text-base sm:text-lg font-bold text-slate-900 leading-snug">
                            {test.test_name}
                          </h3>
                        </div>

                        <div className="flex items-center gap-1.5 bg-blue-50 text-[#1E3A8A] px-2.5 py-1 rounded-lg border border-blue-100 text-xs font-bold flex-shrink-0">
                          <Clock className="w-3.5 h-3.5" />
                          <span>{test.duration} Min</span>
                        </div>
                      </div>

                      {/* Date & Day Badges */}
                      {(test.test_date || test.test_day) && (
                        <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600 pt-1 border-t border-slate-100">
                          {test.test_date && (
                            <span className="inline-flex items-center gap-1 font-semibold text-blue-900 bg-slate-100 px-2 py-0.5 rounded">
                              <Calendar className="w-3 h-3 text-[#1E3A8A]" />
                              {test.test_date}
                            </span>
                          )}
                          {test.test_day && (
                            <span className="inline-flex items-center font-medium text-slate-700 bg-slate-100 px-2 py-0.5 rounded">
                              {test.test_day}
                            </span>
                          )}
                        </div>
                      )}

                      {/* Status Toggle Switch Bar (Screenshot 1) */}
                      <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span
                            className={`w-2.5 h-2.5 rounded-full ${
                              isActive ? 'bg-emerald-500' : 'bg-slate-400'
                            }`}
                          />
                          <span className="text-xs font-bold text-slate-700">
                            Status: {isActive ? 'Active' : 'Deactive'}
                          </span>
                        </div>

                        <button
                          type="button"
                          onClick={() => handleToggleActive(test.id || 0, isActive)}
                          className={`w-12 h-6 flex items-center rounded-full p-1 transition-colors cursor-pointer ${
                            isActive ? 'bg-emerald-600' : 'bg-slate-300'
                          }`}
                        >
                          <div
                            className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                              isActive ? 'translate-x-6' : 'translate-x-0'
                            }`}
                          />
                        </button>
                      </div>

                      {/* Test Completed Status Banner */}
                      {isCompleted && (
                        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 flex items-center gap-2 text-emerald-800 text-xs font-bold">
                          <CheckCircle className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                          <span>Test Completed</span>
                        </div>
                      )}

                      {/* Full-Width Start / Retake Action Button */}
                      <button
                        onClick={() => {
                          SoundManager.playTestStart();
                          onTakeTest(test.id || 0, `Test ${seqNum}: ${test.test_name}`, test.duration || 15);
                        }}
                        className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 px-4 rounded-xl shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer text-sm"
                      >
                        {isCompleted ? (
                          <>
                            <RotateCcw className="w-4 h-4" />
                            <span>Retake Test</span>
                          </>
                        ) : (
                          <>
                            <Play className="w-4 h-4 fill-white" />
                            <span>Take Test</span>
                          </>
                        )}
                      </button>

                      {/* Bottom Action Buttons: Questions, Edit, Delete (Screenshot 1) */}
                      <div className={isSuperAdmin ? "grid grid-cols-3 gap-2.5 pt-1" : "grid grid-cols-2 gap-2.5 pt-1"}>
                        {/* Questions Button */}
                        <button
                          onClick={() => handleViewQuestions(test)}
                          className="bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold py-2.5 px-3 rounded-xl text-xs flex items-center justify-center gap-1.5 border border-slate-300 transition-all cursor-pointer"
                        >
                          <ListOrdered className="w-4 h-4 text-[#1E3A8A]" />
                          <span>Questions</span>
                        </button>

                        {/* Edit Button */}
                        <button
                          onClick={() => {
                            SoundManager.playButtonClick();
                            setTestToEdit(test);
                          }}
                          className="bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold py-2.5 px-3 rounded-xl text-xs flex items-center justify-center gap-1.5 border border-slate-300 transition-all cursor-pointer"
                        >
                          <Edit2 className="w-4 h-4 text-blue-600" />
                          <span>Edit</span>
                        </button>

                        {/* Delete Button (Super Admin Only) */}
                        {isSuperAdmin && (
                          <button
                            onClick={() => {
                              SoundManager.playButtonClick();
                              setTestToDelete(test);
                            }}
                            className="bg-red-50 hover:bg-red-100 text-red-600 font-bold py-2.5 px-3 rounded-xl text-xs flex items-center justify-center gap-1.5 border border-red-200 transition-all cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                            <span>Delete</span>
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ==========================================================
            TAB 1: RESULTS DASHBOARD
           ========================================================== */}
        {selectedTab === 'results' && (
          <div className="space-y-4">
            {/* Test Selector Card */}
            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-3.5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold uppercase tracking-wider text-[#1E3A8A]">
                    Select Test to View Performance
                  </label>
                  <select
                    value={selectedDashboardTestId || ''}
                    onChange={(e) => {
                      SoundManager.playButtonClick();
                      setSelectedDashboardTestId(Number(e.target.value));
                    }}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                  >
                    {tests.map((t) => {
                      const sNum = tests.length - tests.indexOf(t);
                      return (
                        <option key={t.id} value={t.id}>
                          Test {sNum}: {t.test_name} ({t.duration} min)
                        </option>
                      );
                    })}
                  </select>
                </div>

                {/* Filter Student Input */}
                <div className="sm:max-w-xs w-full space-y-1">
                  <label className="text-xs font-bold uppercase tracking-wider text-slate-600">
                    Filter by Student
                  </label>
                  <div className="relative">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3.5 pointer-events-none" />
                    <input
                      type="text"
                      value={resultStudentFilter}
                      onChange={(e) => setResultStudentFilter(e.target.value)}
                      placeholder="Search student name..."
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl py-2.5 pl-9 pr-3 text-sm text-slate-800"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Results Header */}
            <div className="flex items-center justify-between px-1">
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                Student Performance & Rankings
              </h3>
              <span className="text-xs font-bold bg-[#1E3A8A] text-white px-2.5 py-1 rounded-full">
                {dashboardResults.length} Submissions
              </span>
            </div>

            {/* Results List */}
            {isLoadingResults ? (
              <div className="py-16 text-center">
                <div className="w-8 h-8 rounded-full border-3 border-blue-200 border-t-[#1E3A8A] animate-spin mx-auto mb-2" />
                <p className="text-xs text-slate-500">Fetching records from Supabase...</p>
              </div>
            ) : dashboardResults.length === 0 ? (
              <div className="bg-white rounded-2xl p-12 text-center border border-slate-200 shadow-xs space-y-2">
                <Trophy className="w-10 h-10 text-slate-300 mx-auto" />
                <p className="text-base font-bold text-slate-800">No results recorded for this test</p>
                <p className="text-xs text-slate-500">
                  When students or admins complete this test, their scores will appear here.
                </p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {dashboardResults
                  .filter((r) =>
                    (r.studentName || '')
                      .toLowerCase()
                      .includes(resultStudentFilter.trim().toLowerCase())
                  )
                  .map((res, index) => {
                    const rank = index + 1;
                    const rankFormatted = String(rank).padStart(2, '0');

                    const rankGradient =
                      rank % 4 === 1
                        ? 'from-sky-600 to-sky-500'
                        : rank % 4 === 2
                        ? 'from-emerald-600 to-emerald-500'
                        : rank % 4 === 3
                        ? 'from-purple-600 to-purple-500'
                        : 'from-amber-600 to-amber-500';

                    return (
                      <div
                        key={res.id || index}
                        className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden flex items-center justify-between gap-3 hover:border-slate-300 transition-all"
                      >
                        {/* Rank Box */}
                        <div
                          className={`w-14 sm:w-16 self-stretch bg-gradient-to-b ${rankGradient} text-white flex items-center justify-center font-black text-lg sm:text-xl font-mono flex-shrink-0`}
                        >
                          {rankFormatted}
                        </div>

                        {/* Student Info */}
                        <div className="flex-1 py-3 px-1 min-w-0">
                          <h4 className="text-sm sm:text-base font-bold text-slate-900 truncate uppercase">
                            {res.studentName}
                          </h4>
                          <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-0.5">
                            <Calendar className="w-3.5 h-3.5 text-blue-600" />
                            <span>
                              {res.createdAt
                                ? new Date(res.createdAt).toLocaleDateString('gu-IN', {
                                    day: '2-digit',
                                    month: 'short',
                                    year: 'numeric',
                                  })
                                : 'Today'}
                            </span>
                          </div>
                        </div>

                        {/* Score Trophy Badge */}
                        <div className="pr-4 flex-shrink-0">
                          <div className="flex items-center gap-1.5 bg-emerald-50 text-emerald-800 border border-emerald-200 px-3.5 py-1.5 rounded-xl font-black text-sm sm:text-base font-mono">
                            <Trophy className="w-4 h-4 text-emerald-600" />
                            <span>{res.score}</span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
              </div>
            )}
          </div>
        )}

        {/* ==========================================================
            TAB 2: STUDENTS MANAGEMENT (Matches Screenshot 4 & 5)
           ========================================================== */}
        {selectedTab === 'students' && isSuperAdmin && (
          <div className="space-y-4">
            {/* Search row with "+ Add" button (Screenshot 4) */}
            <div className="flex items-center gap-3">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                <input
                  type="text"
                  value={studentSearch}
                  onChange={(e) => setStudentSearch(e.target.value)}
                  placeholder="Search name or mobile..."
                  className="w-full bg-white border border-slate-200 rounded-xl py-2.5 pl-10 pr-3 text-sm text-slate-800 shadow-2xs focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                />
              </div>

              <button
                onClick={() => {
                  SoundManager.playButtonClick();
                  setShowAddStudentModal(true);
                }}
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2.5 px-4 rounded-xl text-xs shadow-xs flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap"
              >
                <UserPlus className="w-4 h-4" />
                <span>+ Add</span>
              </button>
            </div>

            {/* Students List */}
            {students.length === 0 ? (
              <div className="bg-white rounded-2xl p-12 text-center border border-slate-200 shadow-xs space-y-2">
                <Users className="w-10 h-10 text-slate-300 mx-auto" />
                <p className="text-base font-bold text-slate-800">No students registered yet</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {students.map((st) => (
                  <div
                    key={st.id}
                    className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex items-center justify-between gap-3 hover:border-slate-300 transition-colors"
                  >
                    {/* Avatar and info */}
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 font-bold flex-shrink-0">
                        <UserIcon className="w-5 h-5" />
                      </div>
                      <div className="min-w-0 space-y-0.5">
                        <h4 className="text-sm font-bold text-slate-900 truncate">
                          {st.name || 'Student'}
                        </h4>
                        <p className="text-xs text-slate-500 font-mono">Mobile: {st.mobile_number}</p>
                      </div>
                    </div>

                    {/* Action buttons: Edit and Delete */}
                    <div className="flex items-center gap-1 flex-shrink-0">
                      <button
                        type="button"
                        onClick={() => {
                          SoundManager.playButtonClick();
                          setEditingStudent(st);
                        }}
                        className="p-2 text-blue-600 hover:bg-blue-50 rounded-xl transition-colors cursor-pointer"
                        title="Edit Student"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          SoundManager.playButtonClick();
                          setStudentToDelete(st);
                        }}
                        className="p-2 text-red-500 hover:bg-red-50 rounded-xl transition-colors cursor-pointer"
                        title="Delete Student"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ==========================================================
            TAB 3: ADMINS MANAGEMENT (Matches Screenshot 6)
           ========================================================== */}
        {selectedTab === 'admins' && isSuperAdmin && (
          <div className="space-y-4">
            {/* Top full-width "+ Add Admin" button (Screenshot 6) */}
            <button
              onClick={() => {
                SoundManager.playButtonClick();
                setShowAddAdminModal(true);
              }}
              className="w-full bg-[#1E3A8A] hover:bg-blue-800 text-white font-bold py-3 px-4 rounded-2xl text-xs sm:text-sm shadow-xs flex items-center justify-center gap-2 cursor-pointer"
            >
              <UserPlus className="w-4 h-4" />
              <span>+ Add Admin</span>
            </button>

            {/* Search row */}
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
              <input
                type="text"
                value={adminSearch}
                onChange={(e) => setAdminSearch(e.target.value)}
                placeholder="Search admin name or mobile..."
                className="w-full bg-white border border-slate-200 rounded-xl py-2.5 pl-10 pr-3 text-sm text-slate-800 shadow-2xs focus:outline-none focus:ring-2 focus:ring-blue-500/20"
              />
            </div>

            <div className="space-y-3">
              {admins.map((adm) => {
                const isRoot = adm.id === 1 || adm.is_super_admin;
                const isDeactivated = adm.device_id === 'DEACTIVATED';

                return (
                  <div
                    key={adm.id}
                    className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-xs flex items-center justify-between gap-3 hover:border-slate-300 transition-colors"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-10 h-10 rounded-full bg-blue-50 text-[#1E3A8A] flex items-center justify-center font-bold flex-shrink-0">
                        <UserIcon className="w-5 h-5" />
                      </div>
                      <div className="min-w-0 space-y-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-sm font-bold text-slate-900">{adm.name || 'Admin'}</span>
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-md uppercase tracking-wider ${
                              isRoot
                                ? 'bg-blue-900 text-white'
                                : isDeactivated
                                ? 'bg-red-100 text-red-700'
                                : 'bg-emerald-100 text-emerald-800'
                            }`}
                          >
                            {isRoot ? 'SUPER ADMIN' : isDeactivated ? 'DEACTIVATED' : 'ADMIN'}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 font-mono">Mobile: {adm.mobile_number}</p>
                      </div>
                    </div>

                    {!isRoot && (
                      <div className="flex items-center gap-2 flex-shrink-0">
                        {/* Edit Admin Button */}
                        <button
                          type="button"
                          onClick={() => {
                            SoundManager.playButtonClick();
                            setEditingAdmin(adm);
                          }}
                          className="p-2 text-blue-600 hover:bg-blue-50 rounded-xl transition-colors cursor-pointer"
                          title="Edit Admin"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>

                        <button
                          onClick={async () => {
                            SoundManager.playButtonClick();
                            await SupabaseManager.toggleAdminStatus(adm.id || 0, !isDeactivated);
                            SoundManager.playSave();
                            showSnackbar(`Admin ${isDeactivated ? 'Activated' : 'Deactivated'} successfully!`);
                            loadAllData();
                          }}
                          className={`text-xs font-bold px-3 py-1.5 rounded-xl border transition-all cursor-pointer ${
                            isDeactivated
                              ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                              : 'bg-amber-50 text-amber-700 border-amber-200 hover:bg-amber-100'
                          }`}
                        >
                          {isDeactivated ? 'Activate' : 'Deactivate'}
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            SoundManager.playButtonClick();
                            setAdminToDelete(adm);
                          }}
                          className="p-2 text-red-500 hover:bg-red-50 rounded-xl transition-colors cursor-pointer"
                          title="Delete Admin"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ==========================================================
            CREATE / ADD TAB (Matches Screenshot 7, 8, 9)
           ========================================================== */}
        {selectedTab === 'create' && (
          <div className="space-y-4">
            {/* Sub-tab Switcher */}
            <div className="bg-slate-200/80 p-1.5 rounded-2xl flex items-center gap-1.5 max-w-sm mx-auto">
              <button
                type="button"
                onClick={() => {
                  SoundManager.playButtonClick();
                  setCreateSubTab(0);
                }}
                className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                  createSubTab === 0
                    ? 'bg-white text-[#1E3A8A] shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                1. New Test
              </button>
              <button
                type="button"
                onClick={() => {
                  SoundManager.playButtonClick();
                  setCreateSubTab(1);
                }}
                className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                  createSubTab === 1
                    ? 'bg-white text-[#1E3A8A] shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                2. Add Question
              </button>
            </div>

            {/* Sub-tab 0: Create New Test (Screenshot 7 & 8) */}
            {createSubTab === 0 && (
              <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm max-w-xl mx-auto space-y-5">
                <div className="flex items-center gap-2.5 pb-2 border-b border-slate-100">
                  <span className="bg-[#1E3A8A] text-white text-xs font-bold px-3 py-1 rounded-md">
                    Test {tests.length + 1}
                  </span>
                  <div>
                    <h3 className="text-base sm:text-lg font-bold text-slate-900">
                      Create New MCQ Test
                    </h3>
                    <p className="text-xs text-slate-500">Next Test Sequence: Test {tests.length + 1}</p>
                  </div>
                </div>

                <form onSubmit={handleSaveNewTest} className="space-y-4">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                      Test Name
                    </label>
                    <input
                      type="text"
                      value={newTestName}
                      onChange={(e) => setNewTestName(e.target.value)}
                      placeholder="e.g. Mathematics Mock Exam"
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-[#1E3A8A]"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                      Duration (Minutes)
                    </label>
                    <input
                      type="number"
                      min="1"
                      max="180"
                      value={newTestDuration}
                      onChange={(e) => setNewTestDuration(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-[#1E3A8A]"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                        Test Date (DD/MM/YYYY)
                      </label>
                      <div className="relative">
                        <input
                          type="text"
                          value={newTestDate}
                          onChange={(e) => setNewTestDate(e.target.value)}
                          onClick={() => setShowCalendarDatePicker(true)}
                          placeholder="e.g. 20/01/2026"
                          className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 pr-11 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-[#1E3A8A] cursor-pointer"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            SoundManager.playButtonClick();
                            setShowCalendarDatePicker(true);
                          }}
                          className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-[#1E3A8A] transition-colors cursor-pointer"
                          title="Open Calendar"
                        >
                          <Calendar className="w-5 h-5 text-[#1E3A8A]" />
                        </button>
                      </div>
                    </div>

                    {/* Test Day Dropdown (Screenshot 8) */}
                    <div className="space-y-1 relative">
                      <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                        Test Day (e.g. Sunday)
                      </label>
                      <div className="relative">
                        <button
                          type="button"
                          onClick={() => {
                            SoundManager.playButtonClick();
                            setShowNewTestDayDropdown(!showNewTestDayDropdown);
                          }}
                          className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-left text-sm font-semibold text-slate-900 flex items-center justify-between focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-[#1E3A8A] cursor-pointer"
                        >
                          <span>{newTestDay || 'Select Day'}</span>
                          <ChevronDown className="w-4 h-4 text-slate-400" />
                        </button>

                        {showNewTestDayDropdown && (
                          <div className="absolute z-20 top-full mt-1 w-full bg-white border border-slate-200 rounded-2xl shadow-xl overflow-hidden py-1 max-h-48 overflow-y-auto">
                            {DAYS_OF_WEEK.map((day) => (
                              <button
                                key={day}
                                type="button"
                                onClick={() => {
                                  SoundManager.playButtonClick();
                                  setNewTestDay(day);
                                  setShowNewTestDayDropdown(false);
                                }}
                                className={`w-full text-left px-4 py-2.5 text-xs font-bold transition-colors cursor-pointer ${
                                  newTestDay === day
                                    ? 'bg-blue-50 text-[#1E3A8A]'
                                    : 'text-slate-700 hover:bg-slate-50'
                                }`}
                              >
                                {day}
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={isCreatingTest}
                    className="w-full bg-[#1E3A8A] hover:bg-blue-800 text-white font-bold py-3.5 px-4 rounded-xl shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer mt-2"
                  >
                    {isCreatingTest ? (
                      <div className="w-5 h-5 rounded-full border-2 border-white/30 border-t-white animate-spin" />
                    ) : (
                      <span>Save Test & Continue to Questions</span>
                    )}
                  </button>
                </form>
              </div>
            )}

            {/* Sub-tab 1: Add Question (Screenshot 9) */}
            {createSubTab === 1 && (
              <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm max-w-2xl mx-auto space-y-5">
                <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                  <h3 className="text-base sm:text-lg font-bold text-slate-900">
                    Add Question to Test
                  </h3>
                  {createSuccessMsg && (
                    <span className="text-xs font-bold text-emerald-600 bg-emerald-50 border border-emerald-200 px-3 py-1 rounded-lg">
                      {createSuccessMsg}
                    </span>
                  )}
                </div>

                <form onSubmit={handleSaveQuestion} className="space-y-4">
                  {/* Select Test dropdown */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                      Select Test
                    </label>
                    <select
                      value={selectedAddQuestionTestId || ''}
                      onChange={(e) => setSelectedAddQuestionTestId(Number(e.target.value))}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                    >
                      {tests.map((t) => {
                        const sNum = tests.length - tests.indexOf(t);
                        return (
                          <option key={t.id} value={t.id}>
                            Test {sNum}: {t.test_name} ({t.duration} min)
                          </option>
                        );
                      })}
                    </select>
                  </div>

                  {/* Optional Paragraph */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                      Paragraph / Poem (Optional)
                    </label>
                    <textarea
                      rows={3}
                      value={newPassage}
                      onChange={(e) => setNewPassage(e.target.value)}
                      placeholder="Enter reading comprehension paragraph/poem if this question is based on one..."
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                    />
                  </div>

                  {/* Question Text */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                      Question Text
                    </label>
                    <textarea
                      rows={3}
                      value={newQuestionText}
                      onChange={(e) => setNewQuestionText(e.target.value)}
                      placeholder="Type question here (Gujarati / English)..."
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                      required
                    />
                  </div>

                  {/* Question Image (Optional) Box with Upload Image Button */}
                  <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3">
                    <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                      Question Image (Optional)
                    </label>

                    <div className="flex flex-wrap items-center gap-2">
                      <label className="flex items-center gap-1.5 px-3 py-2 bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 rounded-xl text-xs font-bold cursor-pointer shadow-2xs transition-colors">
                        <Upload className="w-4 h-4 text-[#1E3A8A]" />
                        <span>Upload Image (JPG / PNG)</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleAddQuestionImageUpload}
                          className="hidden"
                        />
                      </label>

                      {newImageUrl && (
                        <button
                          type="button"
                          onClick={() => setNewImageUrl('')}
                          className="px-2.5 py-1.5 text-xs text-red-600 font-bold hover:bg-red-50 rounded-lg cursor-pointer"
                        >
                          Remove Image
                        </button>
                      )}
                    </div>

                    {newImageUrl && (
                      <div className="mt-2 border border-slate-200 rounded-xl p-2 bg-white flex justify-center">
                        <img
                          src={newImageUrl}
                          alt="Preview"
                          className="max-h-36 object-contain rounded-lg"
                        />
                      </div>
                    )}
                  </div>

                  {/* Options A, B, C, D */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-700">Option A</label>
                      <input
                        type="text"
                        value={newOptA}
                        onChange={(e) => setNewOptA(e.target.value)}
                        placeholder="Option A text"
                        className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm"
                        required
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-700">Option B</label>
                      <input
                        type="text"
                        value={newOptB}
                        onChange={(e) => setNewOptB(e.target.value)}
                        placeholder="Option B text"
                        className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm"
                        required
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-700">Option C</label>
                      <input
                        type="text"
                        value={newOptC}
                        onChange={(e) => setNewOptC(e.target.value)}
                        placeholder="Option C text"
                        className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm"
                        required
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-700">Option D</label>
                      <input
                        type="text"
                        value={newOptD}
                        onChange={(e) => setNewOptD(e.target.value)}
                        placeholder="Option D text"
                        className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm"
                        required
                      />
                    </div>
                  </div>

                  {/* Correct Option Selector */}
                  <div className="space-y-1.5 pt-1">
                    <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                      Select Correct Answer
                    </label>
                    <div className="grid grid-cols-4 gap-2">
                      {['A', 'B', 'C', 'D'].map((opt) => (
                        <button
                          key={opt}
                          type="button"
                          onClick={() => {
                            SoundManager.playButtonClick();
                            setNewCorrectOpt(opt);
                          }}
                          className={`py-2 rounded-xl text-sm font-bold border-2 transition-all cursor-pointer ${
                            newCorrectOpt === opt
                              ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                              : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          Option {opt}
                        </button>
                      ))}
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={isSavingQuestion}
                    className="w-full bg-[#1E3A8A] hover:bg-blue-800 text-white font-bold py-3.5 px-4 rounded-xl shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer mt-2"
                  >
                    {isSavingQuestion ? (
                      <div className="w-5 h-5 rounded-full border-2 border-white/30 border-t-white animate-spin" />
                    ) : (
                      <span>Save Question to Supabase</span>
                    )}
                  </button>
                </form>
              </div>
            )}
          </div>
        )}
      </main>

      {/* ==========================================================
          MODALS
         ========================================================== */}

      {/* 1. Questions Viewer Modal (Screenshot 2) */}
      {viewingQuestionsTest && (
        <QuestionsViewerModal
          test={viewingQuestionsTest}
          seqNum={tests.length - tests.indexOf(viewingQuestionsTest)}
          questions={testQuestions}
          isLoading={isLoadingQuestions}
          isSuperAdmin={isSuperAdmin}
          onClose={() => setViewingQuestionsTest(null)}
          onEditQuestion={(q) => setEditingQuestion(q)}
          onDeleteQuestion={async (qId) => {
            if (!isSuperAdmin) return;
            await SupabaseManager.deleteQuestion(qId);
            SoundManager.playDelete();
            setTestQuestions((prev) => prev.filter((item) => item.id !== qId));
            showSnackbar('Question deleted successfully!');
          }}
        />
      )}

      {/* 2. Edit Question Modal */}
      {editingQuestion && (
        <EditQuestionModal
          question={editingQuestion}
          onClose={() => setEditingQuestion(null)}
          onSave={async (
            questionId,
            questionText,
            optA,
            optB,
            optC,
            optD,
            correctOpt,
            imageUrl,
            passageText
          ) => {
            const res = await SupabaseManager.updateQuestion(
              questionId,
              questionText,
              optA,
              optB,
              optC,
              optD,
              correctOpt,
              imageUrl,
              passageText
            );

            if (res.question) {
              SoundManager.playSave();
              showSnackbar('Question updated successfully!');
              setTestQuestions((prev) =>
                prev.map((item) => (item.id === questionId ? res.question! : item))
              );
              setEditingQuestion(null);
            } else {
              SoundManager.playError();
              alert(res.error || 'Failed to update question');
            }
          }}
        />
      )}

      {/* 3. Edit Test Modal (Screenshot 3) */}
      {testToEdit && (
        <EditTestModal
          test={testToEdit}
          onClose={() => setTestToEdit(null)}
          onSave={async (testId, name, duration, date, day) => {
            const res = await SupabaseManager.updateTest(testId, name, duration, date, day);
            if (res.test) {
              SoundManager.playSave();
              showSnackbar('Test updated successfully!');
              setTestToEdit(null);
              await loadAllData();
            } else {
              SoundManager.playError();
              alert(res.error || 'Failed to update test');
            }
          }}
        />
      )}

      {/* 4. Delete Test Confirmation Modal with Warning Dialog */}
      {isSuperAdmin && testToDelete && (
        <ConfirmDeleteModal
          title="Delete Test?"
          message="Are you sure you want to delete this test? All associated questions and test scores will also be permanently removed."
          itemDetails={`Test Name: ${testToDelete.test_name} • Duration: ${testToDelete.duration} mins`}
          confirmLabel="Delete Test"
          onConfirm={async () => {
            if (testToDelete.id) {
              await SupabaseManager.deleteTest(testToDelete.id);
              SoundManager.playDelete();
              showSnackbar('Test deleted successfully!');
              setTestToDelete(null);
              await loadAllData();
            }
          }}
          onCancel={() => setTestToDelete(null)}
        />
      )}

      {/* 4b. Delete Student Confirmation Modal with Warning Dialog */}
      {isSuperAdmin && studentToDelete && (
        <ConfirmDeleteModal
          title="Delete Student?"
          message="Are you sure you want to delete this student? All of their test attempts and performance records will be permanently removed."
          itemDetails={`Name: ${studentToDelete.name || 'Unnamed'} • Mobile: ${studentToDelete.mobile_number}`}
          confirmLabel="Delete Student"
          onConfirm={async () => {
            if (studentToDelete.id) {
              await SupabaseManager.deleteUser(studentToDelete.id);
              SoundManager.playDelete();
              showSnackbar('Student deleted successfully!');
              setStudentToDelete(null);
              await loadAllData();
            }
          }}
          onCancel={() => setStudentToDelete(null)}
        />
      )}

      {/* 4c. Delete Admin Confirmation Modal with Warning Dialog */}
      {isSuperAdmin && adminToDelete && (
        <ConfirmDeleteModal
          title="Delete Admin?"
          message="Are you sure you want to delete this administrator? They will permanently lose administrative access to the platform."
          itemDetails={`Name: ${adminToDelete.name || 'Unnamed'} • Mobile: ${adminToDelete.mobile_number}`}
          confirmLabel="Delete Admin"
          onConfirm={async () => {
            if (adminToDelete.id) {
              await SupabaseManager.deleteUser(adminToDelete.id);
              SoundManager.playDelete();
              showSnackbar('Admin deleted successfully!');
              setAdminToDelete(null);
              await loadAllData();
            }
          }}
          onCancel={() => setAdminToDelete(null)}
        />
      )}

      {/* 5. Edit Student Modal (Screenshot 5) */}
      {isSuperAdmin && editingStudent && (
        <EditStudentModal
          student={editingStudent}
          onClose={() => setEditingStudent(null)}
          onUpdate={async (studentId, name, password) => {
            const res = await SupabaseManager.updateUser(studentId, name, password);
            if (res.user) {
              SoundManager.playSave();
              showSnackbar('Student updated successfully!');
              setEditingStudent(null);
              loadAllData();
            } else {
              SoundManager.playError();
              alert(res.error || 'Failed to update student');
            }
          }}
        />
      )}

      {/* 6. Edit Admin Modal (Screenshot 6) */}
      {editingAdmin && (
        <EditAdminModal
          admin={editingAdmin}
          onClose={() => setEditingAdmin(null)}
          onSave={async (adminId, name, mobile, password) => {
            const res = await SupabaseManager.updateUser(adminId, name, password, mobile);
            if (res.user) {
              SoundManager.playSave();
              showSnackbar('Admin updated successfully!');
              setEditingAdmin(null);
              loadAllData();
            } else {
              SoundManager.playError();
              alert(res.error || 'Failed to update admin');
            }
          }}
        />
      )}

      {/* 7. Add Student Modal */}
      {isSuperAdmin && showAddStudentModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 sm:p-7 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900">Add Student</h3>
              <button
                type="button"
                onClick={() => {
                  SoundManager.playButtonClick();
                  setShowAddStudentModal(false);
                }}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={async (e) => {
                e.preventDefault();
                SoundManager.playButtonClick();
                const form = e.target as HTMLFormElement;
                const name = (form.elements.namedItem('sname') as HTMLInputElement).value;
                const mob = (form.elements.namedItem('smob') as HTMLInputElement).value;
                const pass = (form.elements.namedItem('spass') as HTMLInputElement).value;
                const res = await SupabaseManager.registerUser(name, mob, pass, 'student');
                if (res.user) {
                  SoundManager.playSave();
                  showSnackbar('Student added successfully!');
                  setShowAddStudentModal(false);
                  loadAllData();
                } else {
                  SoundManager.playError();
                  alert(res.error || 'Failed to add student');
                }
              }}
              className="space-y-3"
            >
              <div>
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">Student Name</label>
                <input name="sname" required placeholder="Full Name" className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20" />
              </div>
              <div>
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">10-Digit Mobile Number</label>
                <input name="smob" required maxLength={10} placeholder="Mobile Number" className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20" />
              </div>
              <div>
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">Password</label>
                <input name="spass" required type="password" placeholder="Password" className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20" />
              </div>
              <div className="flex gap-2 pt-3">
                <button type="button" onClick={() => setShowAddStudentModal(false)} className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 py-2.5 rounded-xl text-xs font-bold cursor-pointer">
                  Cancel
                </button>
                <button type="submit" className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white py-2.5 rounded-xl text-xs font-bold cursor-pointer">
                  Save Student
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 8. Add Admin Modal */}
      {showAddAdminModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 sm:p-7 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900">Add Admin</h3>
              <button
                type="button"
                onClick={() => {
                  SoundManager.playButtonClick();
                  setShowAddAdminModal(false);
                }}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={async (e) => {
                e.preventDefault();
                SoundManager.playButtonClick();
                const form = e.target as HTMLFormElement;
                const name = (form.elements.namedItem('aname') as HTMLInputElement).value;
                const mob = (form.elements.namedItem('amob') as HTMLInputElement).value;
                const pass = (form.elements.namedItem('apass') as HTMLInputElement).value;
                const res = await SupabaseManager.registerUser(name, mob, pass, 'admin');
                if (res.user) {
                  SoundManager.playSave();
                  showSnackbar('Admin added successfully!');
                  setShowAddAdminModal(false);
                  loadAllData();
                } else {
                  SoundManager.playError();
                  alert(res.error || 'Failed to add admin');
                }
              }}
              className="space-y-3"
            >
              <div>
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">Admin Name</label>
                <input name="aname" required placeholder="Admin Name" className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20" />
              </div>
              <div>
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">10-Digit Mobile Number</label>
                <input name="amob" required maxLength={10} placeholder="10-digit mobile" className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20" />
              </div>
              <div>
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">Password</label>
                <input name="apass" required type="password" placeholder="Password" className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20" />
              </div>
              <div className="flex gap-2 pt-3">
                <button type="button" onClick={() => setShowAddAdminModal(false)} className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 py-2.5 rounded-xl text-xs font-bold cursor-pointer">
                  Cancel
                </button>
                <button type="submit" className="flex-1 bg-[#1E3A8A] hover:bg-blue-800 text-white py-2.5 rounded-xl text-xs font-bold cursor-pointer">
                  Save Admin
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Calendar Date Picker Modal (Material Style as in screenshot) */}
      {showCalendarDatePicker && (
        <CalendarDatePickerModal
          initialDate={newTestDate}
          onClose={() => setShowCalendarDatePicker(false)}
          onSelectDate={(formattedDate, dayOfWeek) => {
            setNewTestDate(formattedDate);
            if (dayOfWeek) {
              setNewTestDay(dayOfWeek);
            }
          }}
        />
      )}

      {/* Snackbar Notification Toast */}
      {snackbarMessage && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 bg-slate-900 text-white px-5 py-3 rounded-2xl shadow-xl flex items-center gap-2.5 text-xs font-bold border border-slate-700 animate-in fade-in slide-in-from-bottom-2">
          <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0" />
          <span>{snackbarMessage}</span>
        </div>
      )}
    </div>
  );
};
