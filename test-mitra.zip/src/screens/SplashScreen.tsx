import React, { useEffect } from 'react';
import { GraduationCap, Sparkles } from 'lucide-react';
import { SoundManager } from '../services/soundManager';
import { SupabaseManager } from '../services/supabaseClient';
import { User } from '../types';

interface SplashScreenProps {
  onNavigateToLogin: () => void;
  onNavigateToStudentHome: (user: User) => void;
  onNavigateToAdminHome: (user: User) => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({
  onNavigateToLogin,
  onNavigateToStudentHome,
  onNavigateToAdminHome,
}) => {
  useEffect(() => {
    // 1. Play App Open Sound (Pleasant welcome tune + voice "ટેસ્ટ મિત્ર" / "Test Mitra")
    SoundManager.playAppOpen(true);

    // Fallback: If browser autoplay policy blocked audio before user gesture,
    // trigger on the very first touch/click anywhere on the window.
    const handleFirstGesture = () => {
      SoundManager.playAppOpen(true);
    };
    window.addEventListener('click', handleFirstGesture, { once: true });
    window.addEventListener('touchstart', handleFirstGesture, { once: true });

    // 2. Check for active session
    const timer = setTimeout(async () => {
      try {
        const savedUserStr = localStorage.getItem('test_mitra_current_user');
        if (savedUserStr) {
          const savedUser = JSON.parse(savedUserStr) as User;
          if (savedUser && savedUser.id) {
            const devId = SupabaseManager.getDeviceId();
            const verification = await SupabaseManager.verifySession(savedUser.id, devId);
            if (verification.user) {
              const u = verification.user;
              localStorage.setItem('test_mitra_current_user', JSON.stringify(u));
              const isTeacherOrAdmin =
                (u.role || '').toLowerCase() === 'admin' ||
                (u.role || '').toLowerCase() === 'teacher';
              if (isTeacherOrAdmin) {
                onNavigateToAdminHome(u);
              } else {
                onNavigateToStudentHome(u);
              }
              return;
            }
          }
        }
      } catch {}

      onNavigateToLogin();
    }, 2000);

    return () => {
      clearTimeout(timer);
      window.removeEventListener('click', handleFirstGesture);
      window.removeEventListener('touchstart', handleFirstGesture);
    };
  }, [onNavigateToAdminHome, onNavigateToLogin, onNavigateToStudentHome]);

  return (
    <div className="min-h-screen w-full bg-gradient-to-b from-[#0F172A] via-[#1E3A8A] to-[#0F2B48] flex flex-col items-center justify-center p-6 text-white text-center select-none cursor-pointer">
      <div className="flex flex-col items-center max-w-sm w-full animate-fade-in">
        {/* Logo Card */}
        <div className="relative mb-6">
          <div className="w-28 h-28 sm:w-32 sm:h-32 rounded-full bg-white flex items-center justify-center shadow-2xl border-4 border-emerald-400">
            <GraduationCap className="w-16 h-16 sm:w-18 sm:h-18 text-[#1E3A8A]" />
          </div>
          <div className="absolute -bottom-1 -right-1 bg-emerald-500 text-white rounded-full p-2 shadow-lg border-2 border-white">
            <Sparkles className="w-4 h-4" />
          </div>
        </div>

        {/* Title */}
        <h1 className="text-3xl sm:text-4xl font-black tracking-wider text-white mb-2 font-display">
          TEST MITRA
        </h1>

        <p className="text-emerald-400 text-base sm:text-lg font-bold tracking-wide mb-3">
          Smart Examination Portal
        </p>

        <p className="text-blue-100/90 text-xs sm:text-sm font-medium leading-relaxed max-w-xs mb-8">
          Online MCQ Test Platform
          <br />
          Simple, Fast & Reliable Assessments
        </p>

        {/* Progress Spinner */}
        <div className="w-7 h-7 rounded-full border-3 border-emerald-400/30 border-t-emerald-400 animate-spin" />
      </div>
    </div>
  );
};
